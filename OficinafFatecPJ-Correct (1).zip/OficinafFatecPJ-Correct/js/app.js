// Aplicação principal do sistema de gestão de oficina mecânica

// Estado global da aplicação
let currentSection = 'dashboard';

// Inicialização da aplicação
document.addEventListener('DOMContentLoaded', async () => {
    try {
        console.log('Inicializando sistema de gestão da oficina...');
        
        // Inicializar banco de dados
        await db.init();
        console.log('Banco de dados inicializado com sucesso');
        
        // Inicializar componentes
        initializeApp();
        
        // Carregar dados iniciais
        await loadDashboard();
        
    } catch (error) {
        console.error('Erro ao inicializar aplicação:', error);
        Utils.showToast('Erro ao inicializar a aplicação. Recarregue a página.', 'error');
    }
});

function initializeApp() {
    // Configurar data atual
    document.getElementById('current-date').textContent = new Date().toLocaleDateString('pt-BR');
    
    // Configurar menu mobile
    document.getElementById('menu-toggle').addEventListener('click', toggleSidebar);
    
    // Configurar navegação
    setupNavigation();
    
    // Configurar filtros e buscas
    setupSearchFilters();
    
    // Configurar responsividade
    setupResponsiveLayout();
    
    // Inicializar ícones Lucide
    lucide.createIcons();
    
    // Mostrar seção inicial
    showSection('dashboard');
}

function setupResponsiveLayout() {
    // Fechar sidebar quando redimensionar para desktop
    window.addEventListener('resize', () => {
        if (window.innerWidth >= 1024) {
            closeSidebar();
        }
        
        // Configurar indicadores de scroll em tabelas
        setupTableScrollIndicators();
    });
    
    // Fechar sidebar ao pressionar ESC
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && window.innerWidth < 1024) {
            closeSidebar();
        }
    });
    
    // Configurar indicadores de scroll inicial
    setupTableScrollIndicators();
}

function setupTableScrollIndicators() {
    // Configurar indicadores de scroll horizontal para tabelas em mobile
    if (window.innerWidth < 1024) {
        document.querySelectorAll('.table-responsive').forEach(container => {
            const table = container.querySelector('table');
            if (table && table.scrollWidth > container.clientWidth) {
                container.classList.add('scrollable');
                
                // Adicionar evento de scroll para esconder o indicador
                let scrollTimeout;
                container.addEventListener('scroll', () => {
                    container.classList.add('scrolling');
                    clearTimeout(scrollTimeout);
                    scrollTimeout = setTimeout(() => {
                        container.classList.remove('scrolling');
                    }, 1000);
                });
            }
        });
    }
}

function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const isOpen = sidebar.classList.contains('open');
    
    if (isOpen) {
        closeSidebar();
    } else {
        openSidebar();
    }
}

function openSidebar() {
    const sidebar = document.getElementById('sidebar');
    const body = document.body;
    
    // Adicionar classe open ao sidebar
    sidebar.classList.add('open');
    
    // Criar overlay se não existir
    let overlay = document.getElementById('sidebar-overlay');
    if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'sidebar-overlay';
        overlay.className = 'sidebar-overlay';
        overlay.addEventListener('click', closeSidebar);
        body.appendChild(overlay);
    }
    
    // Mostrar overlay
    overlay.classList.add('show');
    
    // Prevenir scroll do body
    body.style.overflow = 'hidden';
}

function closeSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebar-overlay');
    const body = document.body;
    
    // Remover classe open do sidebar
    sidebar.classList.remove('open');
    
    // Esconder overlay
    if (overlay) {
        overlay.classList.remove('show');
        setTimeout(() => {
            if (overlay.parentNode) {
                overlay.parentNode.removeChild(overlay);
            }
        }, 300);
    }
    
    // Restaurar scroll do body
    body.style.overflow = '';
}

function setupNavigation() {
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            
            // Remover classe active de todos os links
            document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
            
            // Adicionar classe active ao link clicado
            link.classList.add('active');
        });
    });
}

function setupSearchFilters() {
    // Busca de clientes
    const searchClientes = document.getElementById('search-clientes');
    if (searchClientes) {
        searchClientes.addEventListener('input', debounce(filterClientes, 300));
    }
    
    // Busca de veículos
    const searchVeiculos = document.getElementById('search-veiculos');
    if (searchVeiculos) {
        searchVeiculos.addEventListener('input', debounce(filterVeiculos, 300));
    }
    
    // Busca de peças
    const searchPecas = document.getElementById('search-pecas');
    if (searchPecas) {
        searchPecas.addEventListener('input', debounce(filterPecas, 300));
    }
    
    // Busca de serviços
    const searchServicos = document.getElementById('search-servicos');
    if (searchServicos) {
        searchServicos.addEventListener('input', debounce(filterServicos, 300));
    }
      // Busca de ordens
    const searchOrdens = document.getElementById('search-ordens');
    if (searchOrdens) {
        searchOrdens.addEventListener('input', debounce(applyOrdensFilters, 300));
    }
    
    // Filtro de status das ordens
    const filterStatus = document.getElementById('filter-status');
    if (filterStatus) {
        filterStatus.addEventListener('change', applyOrdensFilters);
    }

   
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function showSection(sectionName) {
    // Esconder todas as seções
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
        section.classList.add('hidden');
    });
    
    // Mostrar seção selecionada
    const targetSection = document.getElementById(`${sectionName}-section`);
    if (targetSection) {
        targetSection.classList.remove('hidden');
        targetSection.classList.add('active', 'fade-in');
    }
    
    // Atualizar título da página
    const titles = {
        dashboard: 'Dashboard',
        clientes: 'Clientes',
        veiculos: 'Veículos',
        pecas: 'Peças',
        servicos: 'Serviços',
        ordens: 'Ordens de Serviço',
        configuracoes: 'Configurações',
    };
    
    document.getElementById('page-title').textContent = titles[sectionName] || 'Dashboard';
    currentSection = sectionName;
    
    // Carregar dados da seção se necessário
    loadSectionData(sectionName);
      // Fechar sidebar no mobile
    if (window.innerWidth < 1024) {
        closeSidebar();
    }
}


// Mensagem de erro
async function loadSectionData(sectionName) {
    try {
        switch (sectionName) {
            case 'dashboard':
                await loadDashboard();
                break;
            case 'clientes':
                await loadClientes();
                break;
            case 'veiculos':
                await loadVeiculos();
                break;
            case 'pecas':
                await loadPecas();
                break;
            case 'servicos':
                await loadServicos();
                break;
            case 'ordens':
                await loadOrdens();
                break;
            case 'configuracoes':
                await loadConfiguracoes();
                break;
        }
    } catch (error) {
        console.error(`Erro ao carregar dados da seção ${sectionName}:`, error);
        Utils.showToast(`Erro ao carregar ${sectionName}`, 'error');
    }
}

// Funções de carregamento de dados

async function loadDashboard() {
    const stats = await db.getDashboardStats();
    
    // Atualizar cards de estatísticas
    document.getElementById('total-clientes').textContent = stats.totalClientes;
    document.getElementById('total-veiculos').textContent = stats.totalVeiculos;
    document.getElementById('total-servicos').textContent = stats.totalServicos;
    document.getElementById('total-ordens-abertas').textContent = stats.ordensAbertas;
    document.getElementById('total-pecas').textContent = stats.totalPecas;
      // Atualizar estatísticas do mês
    document.getElementById('servicos-concluidos').textContent = stats.estatisticasMes.servicosConcluidos;
    document.getElementById('receita-total').textContent = Utils.formatCurrency(stats.estatisticasMes.receitaTotal);
    document.getElementById('pecas-utilizadas').textContent = stats.estatisticasMes.pecasUtilizadas;
    
    // Atualizar ordens recentes
    const ordensRecentesContainer = document.getElementById('ordens-recentes');
    if (stats.ordensRecentes.length === 0) {
        ordensRecentesContainer.innerHTML = '<p class="text-gray-500">Nenhuma ordem de serviço encontrada</p>';
    } else {
        ordensRecentesContainer.innerHTML = stats.ordensRecentes.map(ordem => `
            <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                    <p class="font-medium">${ordem.numero}</p>
                    <p class="text-sm text-gray-500">Cliente ID: ${ordem.clienteId}</p>
                </div>
                <span class="status-badge status-${ordem.status}">${getStatusLabel(ordem.status)}</span>
            </div>
        `).join('');
    }
      // Verificar e alertar sobre estoque baixo
    try {
        const pecasEstoqueBaixo = await db.getPecasEstoqueBaixo();
        const alertasEstoqueContainer = document.getElementById('alertas-estoque');
        
        if (pecasEstoqueBaixo.length === 0) {
        
        } else {
            alertasEstoqueContainer.innerHTML = `
                <div class="space-y-2">
                    <p class="text-red-600 font-medium text-sm">${pecasEstoqueBaixo.length} peça(s) com estoque baixo:</p>
                    ${pecasEstoqueBaixo.map(peca => `
                        <div class="flex justify-between items-center p-2 bg-red-50 rounded border-l-4 border-red-400">
                            <div>
                                <p class="text-sm font-medium text-red-800">${peca.nome}</p>
                                <p class="text-xs text-red-600">Código: ${peca.codigo}</p>
                            </div>
                            <div class="text-right">
                                <p class="text-sm font-bold text-red-800">${peca.estoque}</p>
                                <p class="text-xs text-red-600">Mín: ${peca.estoqueMinimo || 0}</p>
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;
            
            // Também mostrar um toast para alertas críticos
            const nomes = pecasEstoqueBaixo.map(p => p.nome).join(', ');
            Utils.showToast(`Atenção: ${pecasEstoqueBaixo.length} peça(s) com estoque baixo: ${nomes}`, 'warning');
        }
    } catch (error) {
        console.warn('Erro ao verificar estoque baixo:', error);
        document.getElementById('alertas-estoque').innerHTML = '<p class="text-gray-500 text-sm">Erro ao verificar estoque</p>';
    }
}

async function loadClientes() {
    const clientes = await db.getAllClientes();
    const tbody = document.getElementById('clientes-table');
      if (clientes.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" class="text-center py-4 text-gray-500">Nenhum cliente cadastrado</td></tr>';
        return;
    }
      tbody.innerHTML = clientes.map(cliente => `
        <tr class="hover:bg-gray-50">
            <td class="px-6 py-4 whitespace-nowrap" data-label="Nome">
                <div class="text-sm font-medium text-gray-900">${cliente.nome}</div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap" data-label="Email">
                <div class="text-sm text-gray-500">${cliente.email}</div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap" data-label="Telefone">
                <div class="text-sm text-gray-500">${cliente.telefone}</div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium" data-label="Ações">
                <button onclick="editCliente(${cliente.id})" class="text-yellow-600 hover:text-yellow-900 mr-3">
                    <i data-lucide="edit" class="w-4 h-4"></i>
                </button>                <button onclick="deleteCliente(${cliente.id})" class="text-red-600 hover:text-red-900">
                    <i data-lucide="trash-2" class="w-4 h-4"></i>
                </button>
            </td>
        </tr>
    `).join('');
    
    lucide.createIcons();
    setupTableScrollIndicators();
}

async function loadVeiculos() {
    const veiculos = await db.getAllVeiculos();
    const clientes = await db.getAllClientes();
    const tbody = document.getElementById('veiculos-table');
    
    if (veiculos.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" class="text-center py-4 text-gray-500">Nenhum veículo cadastrado</td></tr>';
        return;
    }
      tbody.innerHTML = veiculos.map(veiculo => {
        const cliente = clientes.find(c => c.id === veiculo.clienteId);
        return `
            <tr class="hover:bg-gray-50">
                <td class="px-6 py-4 whitespace-nowrap" data-label="Placa">
                    <div class="text-sm font-medium text-gray-900">${veiculo.placa}</div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap" data-label="Marca/Modelo">
                    <div class="text-sm text-gray-900">${veiculo.marca} ${veiculo.modelo}</div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap" data-label="Ano">
                    <div class="text-sm text-gray-500">${veiculo.ano}</div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap" data-label="Proprietário">
                    <div class="text-sm text-gray-500">${cliente ? cliente.nome : 'Cliente não encontrado'}</div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium" data-label="Ações">
                    <button onclick="editVeiculo(${veiculo.id})" class="text-yellow-600 hover:text-yellow-900 mr-3">
                        <i data-lucide="edit" class="w-4 h-4"></i>
                    </button>
                    <button onclick="deleteVeiculo(${veiculo.id})" class="text-red-600 hover:text-red-900">                <i data-lucide="trash-2" class="w-4 h-4"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join('');
    
    lucide.createIcons();
    setupTableScrollIndicators();
}

async function loadPecas() {
    const pecas = await db.getAllPecas();
    const tbody = document.getElementById('pecas-table');
    
    if (pecas.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center py-4 text-gray-500">Nenhuma peça cadastrada</td></tr>';
        return;
    }
      tbody.innerHTML = pecas.map(peca => {
        const estoqueClass = peca.estoque <= (peca.estoqueMinimo || 0) ? 'estoque-baixo' : 
                           peca.estoque <= (peca.estoqueMinimo || 0) * 2 ? 'estoque-medio' : 'estoque-alto';
        
        return `
            <tr class="hover:bg-gray-50">
                <td class="px-6 py-4 whitespace-nowrap" data-label="Código">
                    <div class="text-sm font-medium text-gray-900">${peca.codigo}</div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap" data-label="Nome">
                    <div class="text-sm text-gray-900">${peca.nome}</div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap" data-label="Marca">
                    <div class="text-sm text-gray-500">${peca.marca || '-'}</div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap" data-label="Preço">
                    <div class="text-sm text-gray-900">${Utils.formatCurrency(peca.preco)}</div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap" data-label="Estoque">
                    <div class="text-sm ${estoqueClass}">${peca.estoque}</div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium" data-label="Ações">
                    <button onclick="editPeca(${peca.id})" class="text-yellow-600 hover:text-yellow-900 mr-3">
                        <i data-lucide="edit" class="w-4 h-4"></i>
                    </button>                    <button onclick="deletePeca(${peca.id})" class="text-red-600 hover:text-red-900">
                        <i data-lucide="trash-2" class="w-4 h-4"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join('');
    
    lucide.createIcons();
    setupTableScrollIndicators();
}


async function loadConfiguracoes() {
    try {
        console.log("Carregando seção de configurações...");
        
        // Apenas inicializar ícones
        lucide.createIcons();
        
    } catch (error) {
        console.error('Erro ao carregar configurações:', error);
    }
}

// Função para exportar backup (JÁ EXISTE - manter como está)
async function exportBackup() {
    try {
        console.log("Iniciando exportação de backup...");
        Utils.showToast('Exportando backup...', 'info');

        const backupData = await db.exportAllData();

        const dataStr = JSON.stringify(backupData, null, 2);
        const dataBlob = new Blob([dataStr], { type: 'application/json' });

        const link = document.createElement('a');
        link.href = URL.createObjectURL(dataBlob);

        const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
        link.download = `oficina-backup-${timestamp}.json`;

        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        URL.revokeObjectURL(link.href);

        Utils.showToast('Backup exportado com sucesso!', 'success');
    } catch (error) {
        console.error('Erro ao exportar backup:', error);
        Utils.showToast('Erro ao exportar backup.', 'error');
    }
}

// Função para importar backup (ADICIONAR ESTA)
async function importBackup() {
    try {
        // Criar input de arquivo dinamicamente
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json';
        input.style.display = 'none';
        
        input.onchange = async (e) => {
            const file = e.target.files[0];
            if (!file) return;
            
            if (!file.name.endsWith('.json')) {
                Utils.showToast('Por favor, selecione um arquivo JSON válido.', 'error');
                return;
            }
            
            const reader = new FileReader();
            reader.onload = async (event) => {
                try {
                    const backupData = JSON.parse(event.target.result);
                    
                    // Confirmar importação
                    if (confirm('⚠️ ATENÇÃO!\n\nIsso substituirá todos os dados atuais. Tem certeza que deseja importar o backup?')) {
                        Utils.showToast('Importando backup...', 'info');
                        await db.importAllData(backupData);
                        
                        // Recarregar toda a aplicação
                        await loadDashboard();
                        await loadClientes();
                        await loadVeiculos();
                        await loadPecas();
                        await loadServicos();
                        await loadOrdens();
                        
                        Utils.showToast('Backup importado com sucesso!', 'success');
                    }
                } catch (error) {
                    console.error('Erro ao importar backup:', error);
                    Utils.showToast('Erro ao importar backup: arquivo inválido.', 'error');
                }
            };
            reader.readAsText(file);
        };
        
        document.body.appendChild(input);
        input.click();
        document.body.removeChild(input);
        
    } catch (error) {
        console.error('Erro no processo de importação:', error);
        Utils.showToast('Erro ao importar backup.', 'error');
    }
}

// Função para confirmar limpeza do banco (JÁ EXISTE - manter como está)
function confirmClearDatabase() {
    const confirmacao = prompt("🚨 AÇÃO IRREVERSÍVEL!\n\nVocê tem certeza que deseja apagar TODOS os dados do sistema?\n\nPara confirmar, digite 'APAGAR TUDO' na caixa abaixo.");

    if (confirmacao === "APAGAR TUDO") {
        console.log("Confirmação recebida. Limpando banco de dados...");
        clearDatabase(); 
    } else {
        Utils.showToast('Ação cancelada.', 'info');
    }
}

// Função para limpar banco (JÁ EXISTE - manter como está)
async function clearDatabase() {
    try {
        Utils.showToast('Limpando banco de dados...', 'info');
        
        await db.clearAllData();
        
        // Recarregar dados na interface
        await loadDashboard();
        await loadClientes();
        await loadVeiculos();
        await loadPecas();
        await loadServicos();
        await loadOrdens();
        
        Utils.showToast('Banco de dados limpo com sucesso!', 'success');
    } catch (error) {
        console.error('Erro ao limpar banco:', error);
        Utils.showToast('Erro ao limpar banco de dados.', 'error');
    }
}



async function loadServicos() {
    const servicos = await db.getAllServicos();
    const tbody = document.getElementById('servicos-table');
    
    if (servicos.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" class="text-center py-4 text-gray-500">Nenhum serviço cadastrado</td></tr>';
        return;
    }
      tbody.innerHTML = servicos.map(servico => `
        <tr class="hover:bg-gray-50">
            <td class="px-6 py-4 whitespace-nowrap" data-label="Nome">
                <div class="text-sm font-medium text-gray-900">${servico.nome}</div>
            </td>
            <td class="px-6 py-4" data-label="Descrição">
                <div class="text-sm text-gray-500">${servico.descricao || '-'}</div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap" data-label="Preço">
                <div class="text-sm text-gray-900">${Utils.formatCurrency(servico.preco)}</div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap" data-label="Duração">
                <div class="text-sm text-gray-500">${servico.duracaoMinutos ? `${servico.duracaoMinutos} min` : '-'}</div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium" data-label="Ações">
                <button onclick="editServico(${servico.id})" class="text-yellow-600 hover:text-yellow-900 mr-3">
                    <i data-lucide="edit" class="w-4 h-4"></i>
                </button>                <button onclick="deleteServico(${servico.id})" class="text-red-600 hover:text-red-900">
                    <i data-lucide="trash-2" class="w-4 h-4"></i>
                </button>
            </td>
        </tr>
    `).join('');

    // Adicione estas funções ao final do seu arquivo app.js

async function exportBackup() {
    try {
        console.log("Iniciando exportação de backup...");
        // A função Utils.showToast já existe no seu código, vamos usá-la
        Utils.showToast('Exportando backup...', 'info');

        const backupData = await db.exportAllData();

        const dataStr = JSON.stringify(backupData, null, 2);
        const dataBlob = new Blob([dataStr], { type: 'application/json' });

        const link = document.createElement('a');
        link.href = URL.createObjectURL(dataBlob);

        const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
        link.download = `isaias-motos-backup-${timestamp}.json`;

        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        URL.revokeObjectURL(link.href);

        Utils.showToast('Backup exportado com sucesso!', 'success');
    } catch (error) {
        console.error('Erro ao exportar backup:', error);
        Utils.showToast('Erro ao exportar backup.', 'error');
    }
}

function confirmClearDatabase() {
    const confirmacao = prompt("AÇÃO IRREVERSÍVEL!\n\nVocê tem certeza que deseja apagar TODOS os dados do sistema? Para confirmar, digite 'APAGAR TUDO' na caixa abaixo.");

    if (confirmacao === "APAGAR TUDO") {
        console.log("Confirmação recebida. Limpando banco de dados...");
        // Chama a função que já existe no seu código
        clearDatabase(); 
    } else {
        Utils.showToast('Ação cancelada.', 'info');
    }
}

    lucide.createIcons();
    setupTableScrollIndicators();
}

async function loadOrdens() {
    const ordens = await db.getAllOrdens();
    const clientes = await db.getAllClientes();
    const veiculos = await db.getAllVeiculos();
    const tbody = document.getElementById('ordens-table');
    
    if (ordens.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center py-4 text-gray-500">Nenhuma ordem de serviço cadastrada</td></tr>';
        return;
    }
    
    tbody.innerHTML = ordens.map(ordem => {
        const cliente = clientes.find(c => c.id === ordem.clienteId);
        const veiculo = veiculos.find(v => v.id === ordem.veiculoId);        return `
            <tr class="hover:bg-gray-50">
                <td class="px-6 py-4 whitespace-nowrap" data-label="Nº Ordem">
                    <div class="text-sm font-medium text-gray-900">${ordem.numero || 'N/A'}</div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap" data-label="Cliente">
                    <div class="text-sm text-gray-900">${cliente ? cliente.nome : 'Cliente não encontrado'}</div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap" data-label="Veículo">
                    <div class="text-sm text-gray-500">${veiculo ? `${veiculo.marca} ${veiculo.modelo}` : 'Veículo não encontrado'}</div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap" data-label="Status">
                    <span class="status-badge status-${ordem.status}">${getStatusLabel(ordem.status)}</span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap" data-label="Data">
                    <div class="text-sm text-gray-500">${Utils.formatDate(ordem.dataAbertura)}</div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap" data-label="Total">
                    <div class="text-sm text-gray-900">${Utils.formatCurrency(ordem.valorTotal || 0)}</div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium" data-label="Ações">
                    <button onclick="shareOrdem(${ordem.id})" class="text-blue-600 hover:text-blue-900 mr-3" title="Compartilhar">
                        <i data-lucide="share-2" class="w-4 h-4"></i>
                    </button>
                    <button onclick="editOrdem(${ordem.id})" class="text-yellow-600 hover:text-yellow-900 mr-3">
                        <i data-lucide="edit" class="w-4 h-4"></i>
                    </button>                    <button onclick="deleteOrdem(${ordem.id})" class="text-red-600 hover:text-red-900">
                        <i data-lucide="trash-2" class="w-4 h-4"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join('');    
    lucide.createIcons();
    setupTableScrollIndicators();
    
    // Remover linha de "nenhum resultado" se existir
    const noResultRow = tbody.querySelector('.no-results-row');
    if (noResultRow) {
        noResultRow.remove();
    }
}

// Funções de salvamento
async function saveCliente(id = null) {
    try {        const cliente = {
            nome: document.getElementById('cliente-nome').value,
            email: document.getElementById('cliente-email').value,
            telefone: document.getElementById('cliente-telefone').value,
            endereco: document.getElementById('cliente-endereco').value
        };
        
        // Validações
        if (!Utils.validateEmail(cliente.email)) {
            Utils.showToast('Email inválido', 'error');
            return;
        }
        
        if (id) {
            cliente.id = id;
            await db.updateCliente(cliente);
            Utils.showToast('Cliente atualizado com sucesso', 'success');
        } else {
            await db.addCliente(cliente);
            Utils.showToast('Cliente adicionado com sucesso', 'success');
        }
        
        await loadClientes();
        await loadDashboard();
        
    } catch (error) {
        console.error('Erro ao salvar cliente:', error);
        Utils.showToast('Erro ao salvar cliente', 'error');
    }
}

async function saveVeiculo(id = null) {
    try {
        const veiculo = {
            placa: document.getElementById('veiculo-placa').value.toUpperCase(),
            clienteId: parseInt(document.getElementById('veiculo-cliente').value),
            marca: document.getElementById('veiculo-marca').value,
            modelo: document.getElementById('veiculo-modelo').value,
            ano: parseInt(document.getElementById('veiculo-ano').value),
            cor: document.getElementById('veiculo-cor').value,
            observacoes: document.getElementById('veiculo-observacoes').value
        };
        
        if (id) {
            veiculo.id = id;
            await db.updateVeiculo(veiculo);
            Utils.showToast('Veículo atualizado com sucesso', 'success');
        } else {
            await db.addVeiculo(veiculo);
            Utils.showToast('Veículo adicionado com sucesso', 'success');
        }
        
        await loadVeiculos();
        await loadDashboard();
        
    } catch (error) {
        console.error('Erro ao salvar veículo:', error);
        Utils.showToast('Erro ao salvar veículo', 'error');
    }
}

async function savePeca(id = null) {
    try {
        const peca = {
            codigo: document.getElementById('peca-codigo').value,
            nome: document.getElementById('peca-nome').value,
            marca: document.getElementById('peca-marca').value,
            preco: parseFloat(document.getElementById('peca-preco').value),
            estoque: parseInt(document.getElementById('peca-estoque').value),
            estoqueMinimo: parseInt(document.getElementById('peca-estoque-minimo').value) || 0,
            descricao: document.getElementById('peca-descricao').value
        };
        
        if (id) {
            peca.id = id;
            await db.updatePeca(peca);
            Utils.showToast('Peça atualizada com sucesso', 'success');
        } else {
            await db.addPeca(peca);
            Utils.showToast('Peça adicionada com sucesso', 'success');
        }
        
        await loadPecas();
        await loadDashboard();
        
    } catch (error) {
        console.error('Erro ao salvar peça:', error);
        Utils.showToast('Erro ao salvar peça', 'error');
    }
}

async function saveServico(id = null) {
    try {
        const servico = {
            nome: document.getElementById('servico-nome').value,
            descricao: document.getElementById('servico-descricao').value,
            preco: parseFloat(document.getElementById('servico-preco').value),
            duracaoMinutos: parseInt(document.getElementById('servico-duracao').value) || null
        };
        
        if (id) {
            servico.id = id;
            await db.updateServico(servico);
            Utils.showToast('Serviço atualizado com sucesso', 'success');
        } else {
            await db.addServico(servico);
            Utils.showToast('Serviço adicionado com sucesso', 'success');
        }
        
        await loadServicos();
        
    } catch (error) {
        console.error('Erro ao salvar serviço:', error);
        Utils.showToast('Erro ao salvar serviço', 'error');
    }
}

async function saveOrdem(id = null) {
    try {
        // Coletar serviços
        const servicos = [];
        document.querySelectorAll('.servico-select').forEach(select => {
            if (select.value) {
                const quantidade = parseInt(select.parentElement.querySelector('.quantidade-servico').value) || 1;
                servicos.push({
                    servicoId: parseInt(select.value),
                    quantidade: quantidade
                });
            }
        });
        
        // Coletar peças
        const pecas = [];
        document.querySelectorAll('.peca-select').forEach(select => {
            if (select.value) {
                const quantidade = parseInt(select.parentElement.querySelector('.quantidade-peca').value) || 1;
                pecas.push({
                    pecaId: parseInt(select.value),
                    quantidade: quantidade
                });
            }
        });
        
        // Verificar estoque das peças ANTES de salvar
        const allPecas = await db.getAllPecas();
        for (const pecaOrdem of pecas) {
            const peca = allPecas.find(p => p.id === pecaOrdem.pecaId);
            if (peca && peca.estoque < pecaOrdem.quantidade) {
                Utils.showToast(`Estoque insuficiente para a peça: ${peca.nome}. Disponível: ${peca.estoque}`, 'error');
                return;
            }
        }
        
        // Calcular valor total
        let valorTotal = 0;
        const allServicos = await db.getAllServicos();
        
        servicos.forEach(s => {
            const servico = allServicos.find(srv => srv.id === s.servicoId);
            if (servico) valorTotal += servico.preco * s.quantidade;
        });
        
        pecas.forEach(p => {
            const peca = allPecas.find(pc => pc.id === p.pecaId);
            if (peca) valorTotal += peca.preco * p.quantidade;
        });        const dataEntrega = document.getElementById('ordem-data-entrega').value;
        const status = document.getElementById('ordem-status').value;
        
        const ordem = {
            clienteId: parseInt(document.getElementById('ordem-cliente').value),
            veiculoId: parseInt(document.getElementById('ordem-veiculo').value),
            status: status,
            descricaoProblema: document.getElementById('ordem-descricao').value,
            observacoes: document.getElementById('ordem-observacoes').value,
            dataEntregaPrevista: dataEntrega ? new Date(dataEntrega).toISOString() : null,
            servicos: servicos,
            pecas: pecas,
            valorTotal: valorTotal
        };
        
        // Definir data de conclusão automaticamente se status for "concluída"
        if (status === 'concluida') {
            ordem.dataConclusao = new Date().toISOString();
        } else {
            // Se não estiver concluída, manter null ou preservar data existente se estava concluída antes
            if (id) {
                const ordemExistente = await db.getOrdemById(id);
                if (ordemExistente && ordemExistente.status === 'concluida' && status !== 'concluida') {
                    ordem.dataConclusao = null; // Remover data de conclusão se mudou de concluída para outro status
                } else if (ordemExistente && ordemExistente.dataConclusao && status !== 'concluida') {
                    ordem.dataConclusao = null;
                }
            }
        }
        
        // Se estiver editando uma ordem, primeiro restaurar o estoque das peças antigas
        if (id) {
            const ordemAntiga = await db.getOrdemById(id);
            if (ordemAntiga && ordemAntiga.pecas) {
                await restaurarEstoque(ordemAntiga.pecas);
            }
        }
        
        // Atualizar estoque das peças (diminuir)
        await atualizarEstoque(pecas, 'subtrair');
          if (id) {
            ordem.id = id;
            // Garantir que o número da ordem seja preservado
            const ordemExistente = await db.getOrdemById(id);
            if (ordemExistente && ordemExistente.numero) {
                ordem.numero = ordemExistente.numero;
            }
            await db.updateOrdem(ordem);
            Utils.showToast('Ordem atualizada com sucesso', 'success');
        } else {
            await db.addOrdem(ordem);
            Utils.showToast('Ordem criada com sucesso', 'success');
        }
        
        await loadOrdens();
        await loadDashboard();
        await loadPecas(); // Recarregar peças para mostrar estoque atualizado
        
    } catch (error) {
        console.error('Erro ao salvar ordem:', error);
        Utils.showToast('Erro ao salvar ordem', 'error');
    }
}

// Funções de edição
async function editCliente(id) {
    const cliente = await db.getClienteById(id);
    if (cliente) {
        openClienteModal(cliente);
    }
}

async function editVeiculo(id) {
    const veiculo = await db.getVeiculoById(id);
    if (veiculo) {
        openVeiculoModal(veiculo);
    }
}

async function editPeca(id) {
    const peca = await db.getPecaById(id);
    if (peca) {
        openPecaModal(peca);
    }
}

async function editServico(id) {
    const servico = await db.getServicoById(id);
    if (servico) {
        openServicoModal(servico);
    }
}

async function editOrdem(id) {
    const ordem = await db.getOrdemById(id);
    if (ordem) {
        openOrdemModal(ordem);
    }
}

// Funções de exclusão
async function deleteCliente(id) {
    if (confirm('Tem certeza que deseja excluir este cliente?')) {
        try {
            await db.delete('clientes', id);
            Utils.showToast('Cliente excluído com sucesso', 'success');
            await loadClientes();
            await loadDashboard();
        } catch (error) {
            console.error('Erro ao excluir cliente:', error);
            Utils.showToast('Erro ao excluir cliente', 'error');
        }
    }
}

async function deleteVeiculo(id) {
    if (confirm('Tem certeza que deseja excluir este veículo?')) {
        try {
            await db.delete('veiculos', id);
            Utils.showToast('Veículo excluído com sucesso', 'success');
            await loadVeiculos();
            await loadDashboard();
        } catch (error) {
            console.error('Erro ao excluir veículo:', error);
            Utils.showToast('Erro ao excluir veículo', 'error');
        }
    }
}

async function deletePeca(id) {
    if (confirm('Tem certeza que deseja excluir esta peça?')) {
        try {
            await db.delete('pecas', id);
            Utils.showToast('Peça excluída com sucesso', 'success');
            await loadPecas();
            await loadDashboard();
        } catch (error) {
            console.error('Erro ao excluir peça:', error);
            Utils.showToast('Erro ao excluir peça', 'error');
        }
    }
}

async function deleteServico(id) {
    if (confirm('Tem certeza que deseja excluir este serviço?')) {
        try {
            await db.delete('servicos', id);
            Utils.showToast('Serviço excluído com sucesso', 'success');
            await loadServicos();
        } catch (error) {
            console.error('Erro ao excluir serviço:', error);
            Utils.showToast('Erro ao excluir serviço', 'error');
        }
    }
}

async function deleteOrdem(id) {
    if (confirm('Tem certeza que deseja excluir esta ordem de serviço?')) {
        try {
            // Primeiro, restaurar o estoque das peças da ordem
            const ordem = await db.getOrdemById(id);
            if (ordem && ordem.pecas) {
                await restaurarEstoque(ordem.pecas);
            }
            
            await db.delete('ordens', id);
            Utils.showToast('Ordem excluída com sucesso', 'success');
            await loadOrdens();
            await loadDashboard();
            await loadPecas(); // Recarregar peças para mostrar estoque atualizado
        } catch (error) {
            console.error('Erro ao excluir ordem:', error);
            Utils.showToast('Erro ao excluir ordem', 'error');
        }
    }
}

// Funções de filtro/busca
function filterClientes() {
    const searchTerm = document.getElementById('search-clientes').value.toLowerCase();
    const rows = document.querySelectorAll('#clientes-table tr');
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(searchTerm) ? '' : 'none';
    });
}

function filterVeiculos() {
    const searchTerm = document.getElementById('search-veiculos').value.toLowerCase();
    const rows = document.querySelectorAll('#veiculos-table tr');
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(searchTerm) ? '' : 'none';
    });
}

function filterPecas() {
    const searchTerm = document.getElementById('search-pecas').value.toLowerCase();
    const rows = document.querySelectorAll('#pecas-table tr');
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(searchTerm) ? '' : 'none';
    });
}

function filterServicos() {
    const searchTerm = document.getElementById('search-servicos').value.toLowerCase();
    const rows = document.querySelectorAll('#servicos-table tr');
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(searchTerm) ? '' : 'none';
    });
}

function filterOrdens() {
    const searchTerm = document.getElementById('search-ordens')?.value?.toLowerCase() || '';
    const statusFilter = document.getElementById('')?.value || '';
    const rows = document.querySelectorAll('#ordens-table tr');
    
    if (rows.length === 0) return;
    
    let visibleCount = 0;
    
    rows.forEach(row => {
        // Pular linhas que não têm células de dados (ex: cabeçalho)
        const cells = row.querySelectorAll('td');
        if (cells.length === 0) {
            return;
        }
        
        const text = row.textContent.toLowerCase();
        const statusBadge = row.querySelector('.status-badge');
        
        // Extrair status corretamente das classes CSS
        let status = '';
        if (statusBadge) {
            const classes = statusBadge.className.split(' ');
            const statusClass = classes.find(cls => cls.startsWith('status-'));
            if (statusClass) {
                status = statusClass.replace('status-', '');
            }
        }
        
        const matchesSearch = searchTerm === '' || text.includes(searchTerm);
        const matchesStatus = statusFilter === '' || status === statusFilter;
        
        const shouldShow = matchesSearch && matchesStatus;
        row.style.display = shouldShow ? '' : 'none';
        
        if (shouldShow) {
            visibleCount++;
        }
    });
    
    // Mostrar mensagem se nenhuma ordem for encontrada
    const tbody = document.getElementById('ordens-table');
    if (visibleCount === 0 && tbody && (searchTerm !== '' || statusFilter !== '')) {
        // Verificar se já existe uma linha de "nenhum resultado"
        let noResultRow = tbody.querySelector('.no-results-row');
        if (!noResultRow) {
            noResultRow = document.createElement('tr');
            noResultRow.className = 'no-results-row';
            noResultRow.innerHTML = '<td colspan="7" class="text-center py-4 text-gray-500">Nenhuma ordem encontrada com os filtros aplicados</td>';
            tbody.appendChild(noResultRow);
        }
        noResultRow.style.display = '';
    } else {
        // Remover linha de "nenhum resultado" se existir
        const noResultRow = tbody?.querySelector('.no-results-row');
        if (noResultRow) {
            noResultRow.style.display = 'none';
        }
    }
}

// Função para aplicar filtros com feedback visual
function applyOrdensFilters() {
    const searchTerm = document.getElementById('search-ordens')?.value?.toLowerCase() || '';
    const statusFilter = document.getElementById('filter-status')?.value || '';
    
    if (searchTerm === '' && statusFilter === '') {
        // Se não há filtros, remover qualquer linha de "nenhum resultado"
        const tbody = document.getElementById('ordens-table');
        const noResultRow = tbody?.querySelector('.no-results-row');
        if (noResultRow) {
            noResultRow.style.display = 'none';
        }
        
        // Mostrar todas as linhas
        const rows = document.querySelectorAll('#ordens-table tr');
        rows.forEach(row => {
            const cells = row.querySelectorAll('td');
            if (cells.length > 0) {
                row.style.display = '';
            }
        });
        
        // Atualizar contador
        updateOrdensCounter();
        return;
    }
    
    // Aplicar filtros normalmente
    filterOrdens();
    updateOrdensCounter();
}

// Função para atualizar contador de ordens visíveis
function updateOrdensCounter() {
    const rows = document.querySelectorAll('#ordens-table tr');
    let visibleCount = 0;
    let totalCount = 0;
    
    rows.forEach(row => {
        const cells = row.querySelectorAll('td');
        if (cells.length > 0 && !row.classList.contains('no-results-row')) {
            totalCount++;
            if (row.style.display !== 'none') {
                visibleCount++;
            }
        }
    });
    
    // Atualizar título da seção com contador
    const sectionTitle = document.querySelector('#ordens-section h3');
    if (sectionTitle) {
        const baseTitle = 'Gerenciar Ordens de Serviço';
        if (visibleCount < totalCount) {
            sectionTitle.textContent = `${baseTitle} (${visibleCount} de ${totalCount})`;
        } else {
            sectionTitle.textContent = baseTitle;
        }
    }
}

// Funções auxiliares
function getStatusLabel(status) {
    const labels = {
        'aberta': 'Aberta',
        'em_andamento': 'Em Andamento',
        'concluida': 'Concluída',
        'cancelada': 'Cancelada'
    };
    return labels[status] || status;
}

// Funções auxiliares para controle de estoque
async function atualizarEstoque(pecas, operacao = 'subtrair') {
    for (const pecaOrdem of pecas) {
        const peca = await db.getPecaById(pecaOrdem.pecaId);
        if (peca) {
            if (operacao === 'subtrair') {
                peca.estoque -= pecaOrdem.quantidade;
            } else if (operacao === 'somar') {
                peca.estoque += pecaOrdem.quantidade;
            }
            
            // Garantir que o estoque não fique negativo
            peca.estoque = Math.max(0, peca.estoque);
            
            await db.updatePeca(peca);
        }
    }
}

async function restaurarEstoque(pecas) {
    await atualizarEstoque(pecas, 'somar');
}

// Funções de backup e restauração
async function exportBackup() {
    try {
        Utils.showToast('Exportando backup...', 'info');
        
        const backupData = await db.exportAllData();
        
        // Criar arquivo JSON para download
        const dataStr = JSON.stringify(backupData, null, 2);
        const dataBlob = new Blob([dataStr], { type: 'application/json' });
        
        // Criar link de download
        const link = document.createElement('a');
        link.href = URL.createObjectURL(dataBlob);
        
        const now = new Date();
        const timestamp = now.toISOString().slice(0, 19).replace(/:/g, '-');
        link.download = `oficina-backup-${timestamp}.json`;
        
        // Simular clique para iniciar download
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        // Limpar URL object
        URL.revokeObjectURL(link.href);
        
        Utils.showToast('Backup exportado com sucesso!', 'success');
    } catch (error) {
        console.error('Erro ao exportar backup:', error);
        Utils.showToast('Erro ao exportar backup: ' + error.message, 'error');
    }
}

async function importBackup(backupData) {
    try {
        Utils.showToast('Importando backup...', 'info');
        
        await db.importAllData(backupData);
        
        // Recarregar dados na interface
        await loadDashboard();
        await loadClientes();
        await loadVeiculos();
        await loadPecas();
        await loadServicos();
        await loadOrdens();
        
        Utils.showToast('Backup importado com sucesso!', 'success');
    } catch (error) {
        console.error('Erro ao importar backup:', error);
        Utils.showToast('Erro ao importar backup: ' + error.message, 'error');
        throw error;
    }
}

async function clearDatabase() {
    try {
        Utils.showToast('Limpando banco de dados...', 'info');
        
        await db.clearAllData();
        
        // Recarregar dados na interface
        await loadDashboard();
        await loadClientes();
        await loadVeiculos();
        await loadPecas();
        await loadServicos();
        await loadOrdens();
        
        // Fechar modal
        const modal = document.querySelector('.modal-overlay');
        if (modal) {
            modal.remove();
        }
        
        Utils.showToast('Banco de dados limpo com sucesso!', 'success');
    } catch (error) {
        console.error('Erro ao limpar banco:', error);
        Utils.showToast('Erro ao limpar banco de dados: ' + error.message, 'error');
    }
}





// Sistema de ordenação para tabelas
class TableSorter {
    constructor() {
        this.currentSort = {};
        this.setupSortableHeaders();
    }

    setupSortableHeaders() {
        // Configurar event listeners para todos os cabeçalhos sortable
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('sortable-header')) {
                this.handleSort(e.target);
            }
        });
    }

    handleSort(header) {
        const table = header.closest('table');
        const tableId = table.querySelector('tbody').id;
        const sortField = header.dataset.sort;

        // Determinar direção da ordenação
        const currentDirection = this.currentSort[tableId]?.field === sortField ? 
            this.currentSort[tableId].direction : null;
        
        let newDirection = 'asc';
        if (currentDirection === 'asc') {
            newDirection = 'desc';
        }

        // Atualizar estado da ordenação
        this.currentSort[tableId] = {
            field: sortField,
            direction: newDirection
        };

        // Atualizar indicadores visuais
        this.updateSortIndicators(table, header, newDirection);

        // Ordenar dados baseado na tabela
        this.sortTableData(tableId, sortField, newDirection);
    }

    updateSortIndicators(table, activeHeader, direction) {
        // Remover indicadores de todos os cabeçalhos
        table.querySelectorAll('.sortable-header').forEach(header => {
            header.classList.remove('sorted-asc', 'sorted-desc');
        });

        // Adicionar indicador ao cabeçalho ativo
        activeHeader.classList.add(direction === 'asc' ? 'sorted-asc' : 'sorted-desc');
    }

    sortTableData(tableId, sortField, direction) {
        // Determinar qual função de carregamento chamar baseado no ID da tabela
        switch (tableId) {
            case 'clientes-table':
                this.sortAndReloadClientes(sortField, direction);
                break;
            case 'veiculos-table':
                this.sortAndReloadVeiculos(sortField, direction);
                break;
            case 'pecas-table':
                this.sortAndReloadPecas(sortField, direction);
                break;
            case 'servicos-table':
                this.sortAndReloadServicos(sortField, direction);
                break;
            case 'ordens-table':
                this.sortAndReloadOrdens(sortField, direction);
                break;
        }
    }

    async sortAndReloadClientes(sortField, direction) {
        try {
            const clientes = await db.getAllClientes();
            const sortedClientes = this.sortArray(clientes, sortField, direction);
            this.renderClientesTable(sortedClientes);
        } catch (error) {
            console.error('Erro ao ordenar clientes:', error);
        }
    }

    async sortAndReloadVeiculos(sortField, direction) {
        try {
            const veiculos = await db.getAllVeiculos();
            const clientes = await db.getAllClientes();
            
            // Adicionar nome do proprietário para ordenação
            const veiculosComProprietario = veiculos.map(veiculo => {
                const cliente = clientes.find(c => c.id === veiculo.clienteId);
                return {
                    ...veiculo,
                    proprietario: cliente ? cliente.nome : 'Cliente não encontrado',
                    marca: `${veiculo.marca} ${veiculo.modelo}`
                };
            });

            const sortedVeiculos = this.sortArray(veiculosComProprietario, sortField, direction);
            this.renderVeiculosTable(sortedVeiculos, clientes);
        } catch (error) {
            console.error('Erro ao ordenar veículos:', error);
        }
    }

    async sortAndReloadPecas(sortField, direction) {
        try {
            const pecas = await db.getAllPecas();
            const sortedPecas = this.sortArray(pecas, sortField, direction);
            this.renderPecasTable(sortedPecas);
        } catch (error) {
            console.error('Erro ao ordenar peças:', error);
        }
    }

    async sortAndReloadServicos(sortField, direction) {
        try {
            const servicos = await db.getAllServicos();
            const sortedServicos = this.sortArray(servicos, sortField, direction);
            this.renderServicosTable(sortedServicos);
        } catch (error) {
            console.error('Erro ao ordenar serviços:', error);
        }
    }

    async sortAndReloadOrdens(sortField, direction) {
        try {
            const ordens = await db.getAllOrdens();
            const clientes = await db.getAllClientes();
            const veiculos = await db.getAllVeiculos();
            
            // Adicionar dados relacionados para ordenação
            const ordensComDados = ordens.map(ordem => {
                const cliente = clientes.find(c => c.id === ordem.clienteId);
                const veiculo = veiculos.find(v => v.id === ordem.veiculoId);
                return {
                    ...ordem,
                    cliente: cliente ? cliente.nome : 'Cliente não encontrado',
                    veiculo: veiculo ? `${veiculo.marca} ${veiculo.modelo} - ${veiculo.placa}` : 'Veículo não encontrado'
                };
            });

            const sortedOrdens = this.sortArray(ordensComDados, sortField, direction);
            this.renderOrdensTable(sortedOrdens, clientes, veiculos);
        } catch (error) {
            console.error('Erro ao ordenar ordens:', error);
        }
    }

    sortArray(array, field, direction) {
        return array.sort((a, b) => {
            let valueA = a[field];
            let valueB = b[field];

            // Tratar valores nulos/undefined
            if (valueA === null || valueA === undefined) valueA = '';
            if (valueB === null || valueB === undefined) valueB = '';

            // Converter para string se não for número
            if (typeof valueA === 'string') valueA = valueA.toLowerCase();
            if (typeof valueB === 'string') valueB = valueB.toLowerCase();

            // Comparação para números - incluir duracaoMinutos
            if (field === 'preco' || field === 'valorTotal' || field === 'estoque' || field === 'ano' || field === 'duracaoMinutos') {
                valueA = parseFloat(valueA) || 0;
                valueB = parseFloat(valueB) || 0;
            }

            // Comparação para datas
            if (field === 'dataAbertura' || field === 'dataCriacao') {
                valueA = new Date(valueA);
                valueB = new Date(valueB);
            }

            let comparison = 0;
            if (valueA > valueB) {
                comparison = 1;
            } else if (valueA < valueB) {
                comparison = -1;
            }

            return direction === 'desc' ? comparison * -1 : comparison;
        });
    }

    renderClientesTable(clientes) {
        const tbody = document.getElementById('clientes-table');
        tbody.innerHTML = clientes.map(cliente => `
            <tr class="hover:bg-gray-50">
                <td class="px-6 py-4 whitespace-nowrap" data-label="Nome">
                    <div class="text-sm font-medium text-gray-900">${cliente.nome}</div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap" data-label="Email">
                    <div class="text-sm text-gray-500">${cliente.email}</div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap" data-label="Telefone">
                    <div class="text-sm text-gray-500">${cliente.telefone}</div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium" data-label="Ações">
                    <button onclick="editCliente(${cliente.id})" class="text-yellow-600 hover:text-yellow-900 mr-3">
                        <i data-lucide="edit" class="w-4 h-4"></i>
                    </button>
                    <button onclick="deleteCliente(${cliente.id})" class="text-red-600 hover:text-red-900">
                        <i data-lucide="trash-2" class="w-4 h-4"></i>
                    </button>
                </td>
            </tr>
        `).join('');
        lucide.createIcons();
    }

    renderVeiculosTable(veiculos, clientes) {
        const tbody = document.getElementById('veiculos-table');
        tbody.innerHTML = veiculos.map(veiculo => {
            const cliente = clientes.find(c => c.id === veiculo.clienteId);
            return `
                <tr class="hover:bg-gray-50">
                    <td class="px-6 py-4 whitespace-nowrap" data-label="Placa">
                        <div class="text-sm font-medium text-gray-900">${veiculo.placa}</div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap" data-label="Marca/Modelo">
                        <div class="text-sm text-gray-900">${veiculo.marca} ${veiculo.modelo}</div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap" data-label="Ano">
                        <div class="text-sm text-gray-500">${veiculo.ano}</div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap" data-label="Proprietário">
                        <div class="text-sm text-gray-500">${cliente ? cliente.nome : 'Cliente não encontrado'}</div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium" data-label="Ações">
                        <button onclick="editVeiculo(${veiculo.id})" class="text-yellow-600 hover:text-yellow-900 mr-3">
                            <i data-lucide="edit" class="w-4 h-4"></i>
                        </button>
                        <button onclick="deleteVeiculo(${veiculo.id})" class="text-red-600 hover:text-red-900">
                            <i data-lucide="trash-2" class="w-4 h-4"></i>
                        </button>
                    </td>
                </tr>
            `;
        }).join('');
        lucide.createIcons();
    }

    renderPecasTable(pecas) {
        const tbody = document.getElementById('pecas-table');
        tbody.innerHTML = pecas.map(peca => {
            const estoqueClass = peca.estoque <= (peca.estoqueMinimo || 0) ? 'estoque-baixo' : 
                               peca.estoque <= (peca.estoqueMinimo || 0) * 2 ? 'estoque-medio' : 'estoque-alto';
            
            return `
                <tr class="hover:bg-gray-50">
                    <td class="px-6 py-4 whitespace-nowrap" data-label="Código">
                        <div class="text-sm font-medium text-gray-900">${peca.codigo}</div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap" data-label="Nome">
                        <div class="text-sm text-gray-900">${peca.nome}</div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap" data-label="Marca">
                        <div class="text-sm text-gray-500">${peca.marca || '-'}</div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap" data-label="Preço">
                        <div class="text-sm text-gray-900">${Utils.formatCurrency(peca.preco)}</div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap" data-label="Estoque">
                        <div class="text-sm ${estoqueClass}">${peca.estoque}</div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium" data-label="Ações">
                        <button onclick="editPeca(${peca.id})" class="text-yellow-600 hover:text-yellow-900 mr-3">
                            <i data-lucide="edit" class="w-4 h-4"></i>
                        </button>
                        <button onclick="deletePeca(${peca.id})" class="text-red-600 hover:text-red-900">
                            <i data-lucide="trash-2" class="w-4 h-4"></i>
                        </button>
                    </td>
                </tr>
            `;
        }).join('');
        lucide.createIcons();
    }

    renderServicosTable(servicos) {
        const tbody = document.getElementById('servicos-table');
        tbody.innerHTML = servicos.map(servico => `
            <tr class="hover:bg-gray-50">
                <td class="px-6 py-4 whitespace-nowrap" data-label="Nome">
                    <div class="text-sm font-medium text-gray-900">${servico.nome}</div>
                </td>
                <td class="px-6 py-4" data-label="Descrição">
                    <div class="text-sm text-gray-500">${servico.descricao || '-'}</div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap" data-label="Preço">
                    <div class="text-sm text-gray-900">${Utils.formatCurrency(servico.preco)}</div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap" data-label="Duração">
                    <div class="text-sm text-gray-500">${servico.duracaoMinutos ? `${servico.duracaoMinutos} min` : '-'}</div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium" data-label="Ações">
                    <button onclick="editServico(${servico.id})" class="text-yellow-600 hover:text-yellow-900 mr-3">
                        <i data-lucide="edit" class="w-4 h-4"></i>
                    </button>                <button onclick="deleteServico(${servico.id})" class="text-red-600 hover:text-red-900">
                        <i data-lucide="trash-2" class="w-4 h-4"></i>
                    </button>
                </td>
            </tr>
        `).join('');
        lucide.createIcons();

       
    }

    renderOrdensTable(ordens, clientes, veiculos) {
        const tbody = document.getElementById('ordens-table');
        tbody.innerHTML = ordens.map(ordem => {
            const cliente = clientes.find(c => c.id === ordem.clienteId);
            const veiculo = veiculos.find(v => v.id === ordem.veiculoId);
            return `
                <tr class="hover:bg-gray-50">
                    <td class="px-6 py-4 whitespace-nowrap" data-label="Nº Ordem">
                        <div class="text-sm font-medium text-gray-900">${ordem.numero || 'N/A'}</div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap" data-label="Cliente">
                        <div class="text-sm text-gray-900">${cliente ? cliente.nome : 'Cliente não encontrado'}</div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap" data-label="Veículo">
                        <div class="text-sm text-gray-500">${veiculo ? `${veiculo.marca} ${veiculo.modelo}` : 'Veículo não encontrado'}</div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap" data-label="Status">
                        <span class="status-badge status-${ordem.status}">${getStatusLabel(ordem.status)}</span>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap" data-label="Data">
                        <div class="text-sm text-gray-500">${Utils.formatDate(ordem.dataAbertura)}</div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap" data-label="Total">
                        <div class="text-sm text-gray-900">${Utils.formatCurrency(ordem.valorTotal || 0)}</div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium" data-label="Ações">
                        <button onclick="shareOrdem(${ordem.id})" class="text-blue-600 hover:text-blue-900 mr-3" title="Compartilhar">
                            <i data-lucide="share-2" class="w-4 h-4"></i>
                        </button>
                        <button onclick="editOrdem(${ordem.id})" class="text-yellow-600 hover:text-yellow-900 mr-3">
                            <i data-lucide="edit" class="w-4 h-4"></i>
                        </button>                    <button onclick="deleteOrdem(${ordem.id})" class="text-red-600 hover:text-red-900">
                            <i data-lucide="trash-2" class="w-4 h-4"></i>
                        </button>
                    </td>
                </tr>
            `;
        }).join('');
        lucide.createIcons();
    }
}

// Função auxiliar para cores dos status
function getStatusColor(status) {
    switch (status) {
        case 'aberta': return 'bg-blue-100 text-blue-800';
        case 'em_andamento': return 'bg-yellow-100 text-yellow-800';
        case 'aguardando_peca': return 'bg-orange-100 text-orange-800';
        case 'concluida': return 'bg-green-100 text-green-800';
        case 'cancelada': return 'bg-red-100 text-red-800';
        default: return 'bg-gray-100 text-gray-800';
 }
}

// Inicializar sistema de ordenação quando a aplicação carregar
let tableSorter;
document.addEventListener('DOMContentLoaded', () => {
    // Inicializar ordenação após um pequeno delay para garantir que tudo esteja carregado
    setTimeout(() => {
        tableSorter = new TableSorter();

    }, 100);
});

// Função de teste para verificar filtros
function testFilterOrdens() {
    console.log('=== Teste dos Filtros de Ordens ===');
    
    const searchInput = document.getElementById('search-ordens');
    const statusFilter = document.getElementById('filter-status');
    const rows = document.querySelectorAll('#ordens-table tr');
    
    console.log('Elementos encontrados:', {
        searchInput: !!searchInput,
        statusFilter: !!statusFilter,
        totalRows: rows.length
    });
    
    if (searchInput) {
        console.log('Valor da busca:', searchInput.value);
    }
    if (statusFilter) {
        console.log('Filtro de status:', statusFilter.value);
    }
    
    // Testar cada linha
    rows.forEach((row, index) => {
        const cells = row.querySelectorAll('td');
        if (cells.length > 0) {
            const statusBadge = row.querySelector('.status-badge');
            let status = '';
            if (statusBadge) {
                const classes = statusBadge.className.split(' ');
                const statusClass = classes.find(cls => cls.startsWith('status-'));
                if (statusClass) {
                    status = statusClass.replace('status-', '');
                }
            }
            console.log(`Linha ${index}:`, {
                status,
                visible: row.style.display !== 'none',
                text: row.textContent.substring(0, 50) + '...'
            });
        }
    });
}

// Função para limpar todos os filtros
function clearOrdensFilters() {
    // Limpar campos de filtro
    const searchInput = document.getElementById('search-ordens');
    const statusSelect = document.getElementById('filter-status');
    
    if (searchInput) searchInput.value = '';
    if (statusSelect) statusSelect.value = '';
    
    // Aplicar filtros vazios (mostrar todas as ordens)
    applyOrdensFilters();
    
    // Feedback visual
    Utils.showToast('Filtros limpos', 'success');
}

async function shareOrdem(id) {
    try {
        // Primeiro, garantir que o jsPDF está carregado
        await loadJsPDF();
        
        const ordem = await db.getOrdemById(id);
        if (!ordem) {
            Utils.showToast('Ordem não encontrada', 'error');
            return;
        }

        const cliente = await db.getClienteById(ordem.clienteId);
        const veiculo = await db.getVeiculoById(ordem.veiculoId);
        const allServicos = await db.getAllServicos();
        const allPecas = await db.getAllPecas();

        // Usar a referência correta do jsPDF
        const { jsPDF } = window.jspdf;
        const pdf = new jsPDF();
        
        // Configurações básicas
        const margin = 15;
        let y = 20;
        const pageHeight = pdf.internal.pageSize.height;

        // Função simples para adicionar texto
        const addText = (text, x, y, fontSize = 10, isBold = false) => {
            pdf.setFontSize(fontSize);
            pdf.setFont('helvetica', isBold ? 'bold' : 'normal');
            pdf.text(text, x, y);
        };

        // Cabeçalho
        addText('OFICINA', margin, y, 16, true);
        y += 10;
        addText(`ORDEM DE SERVIÇO #${ordem.numero || ordem.id}`, margin, y, 14, true);
        y += 15;

        // Linha divisória
        pdf.line(margin, y, 195, y);
        y += 10;

        // Informações do cliente
        addText('CLIENTE:', margin, y, 12, true);
        y += 8;
        addText(`Nome: ${cliente ? cliente.nome : 'Cliente não encontrado'}`, margin, y);
        y += 6;
        if (cliente && cliente.telefone) {
            addText(`Telefone: ${cliente.telefone}`, margin, y);
            y += 6;
        }
        y += 5;

        // Informações do veículo
        addText('VEÍCULO:', margin, y, 12, true);
        y += 8;
        if (veiculo) {
            addText(`${veiculo.marca} ${veiculo.modelo}`, margin, y);
            y += 6;
            addText(`Placa: ${veiculo.placa}`, margin, y);
            y += 6;
            if (veiculo.ano) {
                addText(`Ano: ${veiculo.ano}`, margin, y);
                y += 6;
            }
        } else {
            addText('Veículo não encontrado', margin, y);
            y += 6;
        }
        y += 5;

        // Continuar com o resto do conteúdo...
        // Status e datas
        addText('INFORMAÇÕES DA ORDEM:', margin, y, 12, true);
        y += 8;
        addText(`Status: ${getStatusLabel(ordem.status)}`, margin, y);
        y += 6;
        addText(`Data de Abertura: ${Utils.formatDate(ordem.dataAbertura)}`, margin, y);
        y += 6;
        if (ordem.dataEntregaPrevista) {
            addText(`Entrega Prevista: ${Utils.formatDate(ordem.dataEntregaPrevista)}`, margin, y);
            y += 6;
        }
        if (ordem.dataConclusao) {
            addText(`Data de Conclusão: ${Utils.formatDate(ordem.dataConclusao)}`, margin, y);
            y += 6;
        }
        y += 10;

        // Descrição do problema (com quebra de linha)
        if (ordem.descricaoProblema) {
            addText('PROBLEMA RELATADO:', margin, y, 12, true);
            y += 8;
            
            const problemLines = pdf.splitTextToSize(ordem.descricaoProblema, 180);
            problemLines.forEach(line => {
                if (y > pageHeight - 20) {
                    pdf.addPage();
                    y = 20;
                }
                addText(line, margin, y);
                y += 6;
            });
            y += 5;
        }

        // Serviços
        if (ordem.servicos && ordem.servicos.length > 0) {
            addText('SERVIÇOS REALIZADOS:', margin, y, 12, true);
            y += 8;
            
            let totalServicos = 0;
            ordem.servicos.forEach((servicoOrdem, index) => {
                const servico = allServicos.find(srv => srv.id === servicoOrdem.servicoId);
                if (servico) {
                    if (y > pageHeight - 30) {
                        pdf.addPage();
                        y = 20;
                    }
                    
                    const subtotal = servico.preco * servicoOrdem.quantidade;
                    totalServicos += subtotal;
                    
                    addText(`${index + 1}. ${servico.nome}`, margin, y);
                    y += 6;
                    addText(`   Qtd: ${servicoOrdem.quantidade} x ${Utils.formatCurrency(servico.preco)} = ${Utils.formatCurrency(subtotal)}`, margin + 5, y);
                    y += 8;
                }
            });
            
            addText(`SUBTOTAL SERVIÇOS: ${Utils.formatCurrency(totalServicos)}`, margin, y, 11, true);
            y += 10;
        }

        // Peças
        if (ordem.pecas && ordem.pecas.length > 0) {
            addText('PEÇAS UTILIZADAS:', margin, y, 12, true);
            y += 8;
            
            let totalPecas = 0;
            ordem.pecas.forEach((pecaOrdem, index) => {
                const peca = allPecas.find(p => p.id === pecaOrdem.pecaId);
                if (peca) {
                    if (y > pageHeight - 30) {
                        pdf.addPage();
                        y = 20;
                    }
                    
                    const subtotal = peca.preco * pecaOrdem.quantidade;
                    totalPecas += subtotal;
                    
                    addText(`${index + 1}. ${peca.nome}`, margin, y);
                    y += 6;
                    addText(`   Código: ${peca.codigo}`, margin + 5, y);
                    y += 6;
                    addText(`   Qtd: ${pecaOrdem.quantidade} x ${Utils.formatCurrency(peca.preco)} = ${Utils.formatCurrency(subtotal)}`, margin + 5, y);
                    y += 8;
                }
            });
            
            addText(`SUBTOTAL PEÇAS: ${Utils.formatCurrency(totalPecas)}`, margin, y, 11, true);
            y += 10;
        }

        // Observações
        if (ordem.observacoes) {
            addText('OBSERVAÇÕES:', margin, y, 12, true);
            y += 8;
            
            const observationLines = pdf.splitTextToSize(ordem.observacoes, 180);
            observationLines.forEach(line => {
                if (y > pageHeight - 20) {
                    pdf.addPage();
                    y = 20;
                }
                addText(line, margin, y);
                y += 6;
            });
            y += 5;
        }

        // Total
        pdf.line(margin, y, 195, y);
        y += 8;
        addText(`VALOR TOTAL: ${Utils.formatCurrency(ordem.valorTotal || 0)}`, margin, y, 14, true);
        y += 10;
        pdf.line(margin, y, 195, y);
        y += 15;

        // Rodapé
        addText('Oficina Mecânica Amarela', margin, y);
        y += 6;
        addText(`Emitido em: ${new Date().toLocaleString('pt-BR')}`, margin, y);

        // Salvar
        const fileName = `ordem_servico_${ordem.numero || ordem.id}.pdf`;
        pdf.save(fileName);
        
        Utils.showToast('PDF gerado com sucesso!', 'success');

    } catch (error) {
        console.error('Erro ao gerar PDF:', error);
        Utils.showToast('Erro ao gerar PDF: ' + error.message, 'error');
    }
}

// Função para carregar o jsPDF corretamente
function loadJsPDF() {
    return new Promise((resolve, reject) => {
        // Se já está carregado
        if (window.jspdf && window.jspdf.jsPDF) {
            resolve();
            return;
        }

        // Verificar se já existe uma tag script
        const existingScript = document.querySelector('script[src*="jspdf"]');
        if (existingScript) {
            // Aguardar o carregamento
            existingScript.onload = resolve;
            existingScript.onerror = reject;
            return;
        }

        // Criar novo script
        const script = document.createElement('script');
        script.src = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js';
        script.onload = () => {
            // Aguardar um pouco para garantir que a biblioteca está pronta
            setTimeout(resolve, 100);
        };
        script.onerror = () => reject(new Error('Falha ao carregar jsPDF'));
        document.head.appendChild(script);
    });
    async function emitirNFe(id) {
    try {
        const ordem = await db.getOrdemById(id);
        if (!ordem) {
            Utils.showToast('Ordem não encontrada', 'error');
            return;
        }

        const cliente = await db.getClienteById(ordem.clienteId);
        const veiculo = await db.getVeiculoById(ordem.veiculoId);
        const allServicos = await db.getAllServicos();
        const allPecas = await db.getAllPecas();

        // Configurações para impressão em bobina (80mm)
        const { jsPDF } = window.jspdf;
        const pdf = new jsPDF({
            orientation: 'portrait',
            unit: 'mm',
            format: [80, 297] // Largura fixa de 80mm (bobina), altura dinâmica
        });

        // Configurações
        const margin = 3;
        const maxWidth = 74; // 80mm - margens
        let y = 5;
        const lineHeight = 4;
        const fontSize = 8;

        // Dados da empresa (configure com seus dados fiscais)
        const dadosEmpresa = {
            nome: 'OFICINA MECÂNICA AMARELA LTDA',
            cnpj: '12.345.678/0001-90',
            ie: '123.456.789.012',
            endereco: 'RUA DAS OFICINAS, 123 - CENTRO',
            cidade: 'SÃO PAULO/SP',
            telefone: '(11) 9999-9999'
        };

        // Função para adicionar texto formatado para bobina
        const addText = (text, y, options = {}) => {
            const { align = 'left', fontSize = 8, bold = false } = options;
            pdf.setFontSize(fontSize);
            pdf.setFont('helvetica', bold ? 'bold' : 'normal');
            
            let x = margin;
            if (align === 'center') {
                x = 40; // Centro da bobina
            } else if (align === 'right') {
                x = maxWidth - margin;
            }
            
            pdf.text(text, x, y, { align });
            return y + lineHeight;
        };

        // Função para linha divisória
        const addLine = (y) => {
            pdf.setDrawColor(0, 0, 0);
            pdf.setLineWidth(0.1);
            pdf.line(margin, y, maxWidth, y);
            return y + 2;
        };

        // Função para quebrar texto longo
        const splitText = (text, maxLength = 36) => {
            const words = text.split(' ');
            const lines = [];
            let currentLine = '';
            
            words.forEach(word => {
                if ((currentLine + word).length <= maxLength) {
                    currentLine += (currentLine ? ' ' : '') + word;
                } else {
                    if (currentLine) lines.push(currentLine);
                    currentLine = word;
                }
            });
            if (currentLine) lines.push(currentLine);
            
            return lines;
        };

        // ========== CABEÇALHO DA NF-e ==========
        y = addText('----------------------------------------', y, { align: 'center' });
        y = addText('** NOTA FISCAL ELETRÔNICA **', y, { align: 'center', bold: true });
        y = addText('----------------------------------------', y, { align: 'center' });
        y = addText(dadosEmpresa.nome, y, { align: 'center', bold: true });
        
        const nomeLines = splitText(dadosEmpresa.nome.toUpperCase(), 36);
        nomeLines.forEach(line => {
            y = addText(line, y, { align: 'center', bold: true });
        });
        
        y = addText(`CNPJ: ${dadosEmpresa.cnpj}`, y, { align: 'center' });
        y = addText(`IE: ${dadosEmpresa.ie}`, y, { align: 'center' });
        y = addText(dadosEmpresa.endereco, y, { align: 'center' });
        y = addText(dadosEmpresa.cidade, y, { align: 'center' });
        y = addText(dadosEmpresa.telefone, y, { align: 'center' });
        y = addLine(y);

        // ========== DADOS DA NOTA ==========
        y = addText(`NFC-e N°: ${ordem.numeroNFe || '000001'}`, y, { bold: true });
        y = addText(`Série: 1`, y);
        y = addText(`Data Emissão: ${new Date().toLocaleString('pt-BR')}`, y);
        y = addText(`Consumidor: ${cliente ? cliente.nome : 'CONSUMIDOR NÃO IDENTIFICADO'}`, y, { bold: true });
        
        if (cliente && cliente.cpfCnpj) {
            y = addText(`CPF/CNPJ: ${cliente.cpfCnpj}`, y);
        }
        
        y = addText('----------------------------------------', y, { align: 'center' });

        // ========== VEÍCULO ==========
        if (veiculo) {
            y = addText('** VEÍCULO **', y, { align: 'center', bold: true });
            y = addText(`${veiculo.marca} ${veiculo.modelo}`, y, { align: 'center' });
            y = addText(`Placa: ${veiculo.placa}`, y, { align: 'center' });
            if (veiculo.ano) {
                y = addText(`Ano: ${veiculo.ano}`, y, { align: 'center' });
            }
            y = addText('----------------------------------------', y, { align: 'center' });
        }

        // ========== SERVIÇOS ==========
        y = addText('** SERVIÇOS PRESTADOS **', y, { align: 'center', bold: true });
        
        let totalServicos = 0;
        if (ordem.servicos && ordem.servicos.length > 0) {
            ordem.servicos.forEach((servicoOrdem, index) => {
                const servico = allServicos.find(srv => srv.id === servicoOrdem.servicoId);
                if (servico) {
                    const subtotal = servico.preco * servicoOrdem.quantidade;
                    totalServicos += subtotal;
                    
                    // Descrição do serviço
                    const descricao = `${servico.nome} (${servicoOrdem.quantidade} x ${Utils.formatCurrency(servico.preco)})`;
                    const descLines = splitText(descricao, 36);
                    descLines.forEach(line => {
                        y = addText(line, y);
                    });
                    
                    y = addText(`R$ ${subtotal.toFixed(2).padStart(10)}`, y, { align: 'right' });
                }
            });
        }
        y = addText(`SUBTOTAL SERVIÇOS: R$ ${totalServicos.toFixed(2)}`, y, { align: 'right', bold: true });
        y = addText('----------------------------------------', y, { align: 'center' });

        // ========== PEÇAS ==========
        y = addText('** PEÇAS UTILIZADAS **', y, { align: 'center', bold: true });
        
        let totalPecas = 0;
        if (ordem.pecas && ordem.pecas.length > 0) {
            ordem.pecas.forEach((pecaOrdem, index) => {
                const peca = allPecas.find(p => p.id === pecaOrdem.pecaId);
                if (peca) {
                    const subtotal = peca.preco * pecaOrdem.quantidade;
                    totalPecas += subtotal;
                    
                    const descricao = `${peca.nome} (${pecaOrdem.quantidade} x ${Utils.formatCurrency(peca.preco)})`;
                    const descLines = splitText(descricao, 36);
                    descLines.forEach(line => {
                        y = addText(line, y);
                    });
                    
                    y = addText(`R$ ${subtotal.toFixed(2).padStart(10)}`, y, { align: 'right' });
                }
            });
        }
        y = addText(`SUBTOTAL PEÇAS: R$ ${totalPecas.toFixed(2)}`, y, { align: 'right', bold: true });
        y = addText('----------------------------------------', y, { align: 'center' });

        // ========== RESUMO FISCAL ==========
        const valorTotal = ordem.valorTotal || (totalServicos + totalPecas);
        const icms = valorTotal * 0.18; // Exemplo: 18% de ICMS
        const valorLiquido = valorTotal - icms;

        y = addText('** RESUMO FISCAL **', y, { align: 'center', bold: true });
        y = addText(`VALOR TOTAL: R$ ${valorTotal.toFixed(2)}`, y, { align: 'right', bold: true });
        y = addText(`ICMS (18%): R$ ${icms.toFixed(2)}`, y, { align: 'right' });
        y = addText(`VALOR LÍQUIDO: R$ ${valorLiquido.toFixed(2)}`, y, { align: 'right', bold: true });
        y = addText('----------------------------------------', y, { align: 'center' });

        // ========== FORMA DE PAGAMENTO ==========
        y = addText('** FORMA DE PAGAMENTO **', y, { align: 'center', bold: true });
        if (ordem.formaPagamento) {
            y = addText(ordem.formaPagamento.toUpperCase(), y, { align: 'center' });
        } else {
            y = addText('A COMBINAR', y, { align: 'center' });
        }
        y = addText('----------------------------------------', y, { align: 'center' });

        // ========== RODAPÉ FISCAL ==========
        y = addText('** INFORMAÇÕES FISCAIS **', y, { align: 'center', bold: true });
        y = addText('NFC-e N°: ' + (ordem.numeroNFe || '000001'), y, { align: 'center' });
        y = addText('Série: 1', y, { align: 'center' });
        y = addText('Emissão: ' + new Date().toLocaleString('pt-BR'), y, { align: 'center' });
        y = addText('Protocolo: ' + gerarProtocolo(), y, { align: 'center' });
        y = addText('----------------------------------------', y, { align: 'center' });

        // ========== CHAVE DE ACESSO ==========
        const chaveAcesso = gerarChaveAcesso();
        y = addText('CHAVE DE ACESSO:', y, { align: 'center', bold: true });
        y = addText(chaveAcesso.substring(0, 36), y, { align: 'center', fontSize: 6 });
        y = addText(chaveAcesso.substring(36), y, { align: 'center', fontSize: 6 });
        
        y = addText('----------------------------------------', y, { align: 'center' });
        y = addText('Consulte pela Chave de Acesso em:', y, { align: 'center', fontSize: 6 });
        y = addText('www.sefaz.es.gov.br/nfce/consulta', y, { align: 'center', fontSize: 6 });
        
        y = addText('** OBRIGADO PELA PREFERÊNCIA! **', y, { align: 'center', bold: true });

        // Salvar PDF
        const fileName = `nfe_${ordem.numeroNFe || ordem.id}_${Date.now()}.pdf`;
        pdf.save(fileName);
        
        Utils.showToast('NF-e gerada com sucesso!', 'success');

    } catch (error) {
        console.error('Erro ao gerar NF-e:', error);
        Utils.showToast('Erro ao gerar NF-e: ' + error.message, 'error');
    }
}

// Funções auxiliares para dados fiscais
function gerarProtocolo() {
    return '12345678901234567890';
}

function gerarChaveAcesso() {
    // Gerar uma chave de acesso fictícia no formato NFC-e
    const random = Math.random().toString(36).substring(2, 15);
    return 'NFe' + random.padEnd(41, '0').substring(0, 41);
}

// Função para enviar para impressora térmica (opcional)
function imprimirBobina() {
    // Esta função seria específica para sua impressora térmica
    // Exemplo genérico:
    if (window.impressoraTermica) {
        // Lógica de impressão direta na bobina
        window.impressoraTermica.imprimirNFCe(dadosNFe);
    } else {
        // Fallback para PDF
        emitirNFe(id);
    }
}
}



