
  # Sistema gestão auto

  This is a code bundle for Sistema gestão auto. The original project is available at https://www.figma.com/design/PO3gcqhk1P4NBHdel3VVE6/Sistema-gest%C3%A3o-auto.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  