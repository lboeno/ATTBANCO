import { useState, useEffect } from 'react';
import { TrendingUp, Users, Bike, ClipboardList, Package, AlertTriangle, Calendar, DollarSign } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Button } from './ui/button';
import { dashboardAPI, clientesAPI, motosAPI, ordensAPI } from '../utils/api';

const statsCards = [
  {
    title: 'Total de Clientes',
    value: '248',
    change: '+12.5%',
    changeType: 'positive',
    icon: Users,
    description: 'Novos clientes este mês'
  },
  {
    title: 'Motos Cadastradas',
    value: '312',
    change: '+8.2%',
    changeType: 'positive',
    icon: Bike,
    description: 'Motos ativas no sistema'
  },
  {
    title: 'Ordens Ativas',
    value: '45',
    change: '-5.1%',
    changeType: 'negative',
    icon: ClipboardList,
    description: 'Serviços em andamento'
  },
  {
    title: 'Faturamento Mensal',
    value: 'R$ 28.450',
    change: '+15.3%',
    changeType: 'positive',
    icon: DollarSign,
    description: 'Receita deste mês'
  }
];

const recentOrders = [
  {
    id: 'OS-2024-001',
    cliente: 'João Silva',
    moto: 'Honda CB 600F',
    servico: 'Revisão Completa',
    status: 'Em Andamento',
    prazo: '2024-01-15',
    valor: 'R$ 450,00'
  },
  {
    id: 'OS-2024-002',
    cliente: 'Maria Santos',
    moto: 'Yamaha MT-03',
    servico: 'Troca de Óleo',
    status: 'Concluído',
    prazo: '2024-01-12',
    valor: 'R$ 120,00'
  },
  {
    id: 'OS-2024-003',
    cliente: 'Pedro Costa',
    moto: 'Kawasaki Ninja 400',
    servico: 'Reparo do Motor',
    status: 'Aguardando Peças',
    prazo: '2024-01-20',
    valor: 'R$ 1.200,00'
  }
];

const stockAlerts = [
  { item: 'Óleo 10W40', quantidade: 5, minimo: 10 },
  { item: 'Filtro de Ar Honda', quantidade: 2, minimo: 5 },
  { item: 'Pastilha de Freio', quantidade: 8, minimo: 15 }
];

interface DashboardStats {
  totalClientes: number;
  totalMotos: number;
  ordensAtivas: number;
  faturamentoMensal: number;
  clientesAtivos: number;
}

export function Dashboard() {
  const [stats, setStats] = useState<DashboardStats>({
    totalClientes: 0,
    totalMotos: 0,
    ordensAtivas: 0,
    faturamentoMensal: 0,
    clientesAtivos: 0
  });
  const [recentOrders, setRecentOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [statsResponse, ordensResponse] = await Promise.all([
        dashboardAPI.getStats(),
        ordensAPI.getAll()
      ]);

      setStats(statsResponse.stats);
      setRecentOrders(ordensResponse.ordens.slice(0, 3));
    } catch (error) {
      console.error('Error loading dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleInitSampleData = async () => {
    try {
      await dashboardAPI.initSampleData();
      alert('Dados de exemplo criados com sucesso!');
      loadData();
    } catch (error) {
      console.error('Error creating sample data:', error);
      alert('Erro ao criar dados de exemplo: ' + (error as Error).message);
    }
  };

  if (loading) {
    return (
      <div className="p-6 flex items-center justify-center min-h-96">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-muted-foreground">Carregando dashboard...</p>
        </div>
      </div>
    );
  }

  const statsCards = [
    {
      title: 'Total de Clientes',
      value: stats.totalClientes.toString(),
      change: '+12.5%',
      changeType: 'positive',
      icon: Users,
      description: 'Clientes cadastrados'
    },
    {
      title: 'Motos Cadastradas',
      value: stats.totalMotos.toString(),
      change: '+8.2%',
      changeType: 'positive',
      icon: Bike,
      description: 'Motos ativas no sistema'
    },
    {
      title: 'Ordens Ativas',
      value: stats.ordensAtivas.toString(),
      change: '-5.1%',
      changeType: 'negative',
      icon: ClipboardList,
      description: 'Serviços em andamento'
    },
    {
      title: 'Faturamento Mensal',
      value: `R$ ${stats.faturamentoMensal.toFixed(2)}`,
      change: '+15.3%',
      changeType: 'positive',
      icon: DollarSign,
      description: 'Receita deste mês'
    }
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statsCards.map((card, index) => {
          const Icon = card.icon;
          return (
            <Card key={index} className="bg-white border-border rounded-xl shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  {card.title}
                </CardTitle>
                <Icon className="w-4 h-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-semibold text-foreground">{card.value}</div>
                <div className="flex items-center space-x-2 mt-2">
                  <Badge 
                    variant={card.changeType === 'positive' ? 'default' : 'secondary'}
                    className={card.changeType === 'positive' ? 'bg-success' : 'bg-secondary'}
                  >
                    {card.change}
                  </Badge>
                  <p className="text-xs text-muted-foreground">{card.description}</p>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Orders */}
        <Card className="lg:col-span-2 bg-white border-border rounded-xl shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-foreground">Ordens de Serviço Recentes</CardTitle>
            <CardDescription className="text-muted-foreground">
              Últimas ordens de serviço criadas no sistema
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentOrders.map((order, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-accent rounded-lg border border-border">
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-foreground">{order.id}</h4>
                      <Badge 
                        variant={
                          order.status === 'Concluído' ? 'default' : 
                          order.status === 'Em Andamento' ? 'secondary' : 
                          'outline'
                        }
                        className={
                          order.status === 'Concluído' ? 'bg-success' :
                          order.status === 'Em Andamento' ? 'bg-primary' :
                          'bg-secondary'
                        }
                      >
                        {order.status}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{order.cliente} • {order.moto}</p>
                    <p className="text-sm font-medium text-foreground">{order.servico}</p>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-xs text-muted-foreground flex items-center">
                        <Calendar className="w-3 h-3 mr-1" />
                        Prazo: {order.prazo}
                      </span>
                      <span className="text-sm font-medium text-primary">{order.valor}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-4 text-center">
              <Button variant="outline" className="w-full">Ver Todas as Ordens</Button>
            </div>
          </CardContent>
        </Card>

        {/* Stock Alerts */}
        <Card className="bg-white border-border rounded-xl shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-foreground flex items-center">
              <AlertTriangle className="w-5 h-5 mr-2 text-secondary" />
              Alertas de Estoque
            </CardTitle>
            <CardDescription className="text-muted-foreground">
              Itens com estoque baixo
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {stockAlerts.map((alert, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-foreground">{alert.item}</span>
                    <Badge variant="outline" className="text-secondary border-secondary">
                      {alert.quantidade} un.
                    </Badge>
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <span>Estoque atual</span>
                      <span>Mínimo: {alert.minimo}</span>
                    </div>
                    <Progress 
                      value={(alert.quantidade / alert.minimo) * 100} 
                      className="h-2"
                    />
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-4">
              <Button variant="outline" size="sm" className="w-full">
                <Package className="w-4 h-4 mr-2" />
                Gerenciar Estoque
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card className="bg-white border-border rounded-xl shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-foreground">Ações Rápidas</CardTitle>
          <CardDescription className="text-muted-foreground">
            Funcionalidades mais utilizadas
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Button className="h-20 flex flex-col items-center justify-center space-y-2 bg-primary hover:bg-primary/90">
              <ClipboardList className="w-6 h-6" />
              <span className="text-sm">Nova Ordem</span>
            </Button>
            <Button variant="outline" className="h-20 flex flex-col items-center justify-center space-y-2">
              <Users className="w-6 h-6" />
              <span className="text-sm">Novo Cliente</span>
            </Button>
            <Button variant="outline" className="h-20 flex flex-col items-center justify-center space-y-2">
              <Bike className="w-6 h-6" />
              <span className="text-sm">Nova Moto</span>
            </Button>
            <Button variant="outline" className="h-20 flex flex-col items-center justify-center space-y-2">
              <Package className="w-6 h-6" />
              <span className="text-sm">Entrada Estoque</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}