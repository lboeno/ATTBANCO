import { useState, useEffect } from 'react';
import { Plus, Search, Edit, Trash2, User, Calendar, MapPin } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { motosAPI, clientesAPI } from '../utils/api';

export function Motos() {
  const [motos, setMotos] = useState<any[]>([]);
  const [clientes, setClientes] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    marca: '',
    modelo: '',
    ano: '',
    cor: '',
    placa: '',
    chassis: '',
    km: '',
    proprietarioId: ''
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [motosResponse, clientesResponse] = await Promise.all([
        motosAPI.getAll(),
        clientesAPI.getAll()
      ]);
      setMotos(motosResponse.motos);
      setClientes(clientesResponse.clientes);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateMoto = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      await motosAPI.create(formData);
      setIsModalOpen(false);
      setFormData({
        marca: '',
        modelo: '',
        ano: '',
        cor: '',
        placa: '',
        chassis: '',
        km: '',
        proprietarioId: ''
      });
      loadData();
      alert('Moto cadastrada com sucesso!');
    } catch (error) {
      console.error('Error creating motorcycle:', error);
      alert('Erro ao cadastrar moto: ' + (error as Error).message);
    }
  };

  const handleDeleteMoto = async (id: string) => {
    if (confirm('Tem certeza que deseja excluir esta moto?')) {
      try {
        await motosAPI.delete(id);
        loadData();
        alert('Moto excluída com sucesso!');
      } catch (error) {
        console.error('Error deleting motorcycle:', error);
        alert('Erro ao excluir moto: ' + (error as Error).message);
      }
    }
  };

  const filteredMotos = motos.filter(moto =>
    moto.marca?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    moto.modelo?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    moto.placa?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    moto.proprietario?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Em Dia':
        return 'bg-success';
      case 'Revisão Próxima':
        return 'bg-primary';
      case 'Revisão Atrasada':
        return 'bg-secondary';
      default:
        return 'bg-muted';
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Motocicletas</h1>
          <p className="text-muted-foreground">Gerencie o cadastro de motocicletas</p>
        </div>
        
        <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-primary/90">
              <Plus className="w-4 h-4 mr-2" />
              Nova Moto
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Cadastrar Nova Motocicleta</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleCreateMoto}>
              <div className="grid grid-cols-2 gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="marca">Marca</Label>
                  <Select value={formData.marca} onValueChange={(value) => setFormData(prev => ({ ...prev, marca: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a marca" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Honda">Honda</SelectItem>
                      <SelectItem value="Yamaha">Yamaha</SelectItem>
                      <SelectItem value="Kawasaki">Kawasaki</SelectItem>
                      <SelectItem value="Suzuki">Suzuki</SelectItem>
                      <SelectItem value="BMW">BMW</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="modelo">Modelo</Label>
                  <Input 
                    id="modelo" 
                    placeholder="Modelo da moto"
                    value={formData.modelo}
                    onChange={(e) => setFormData(prev => ({ ...prev, modelo: e.target.value }))}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="ano">Ano</Label>
                  <Input 
                    id="ano" 
                    type="number" 
                    placeholder="2020"
                    value={formData.ano}
                    onChange={(e) => setFormData(prev => ({ ...prev, ano: e.target.value }))}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cor">Cor</Label>
                  <Input 
                    id="cor" 
                    placeholder="Cor da moto"
                    value={formData.cor}
                    onChange={(e) => setFormData(prev => ({ ...prev, cor: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="placa">Placa</Label>
                  <Input 
                    id="placa" 
                    placeholder="ABC-1234"
                    value={formData.placa}
                    onChange={(e) => setFormData(prev => ({ ...prev, placa: e.target.value }))}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="km">Quilometragem</Label>
                  <Input 
                    id="km" 
                    type="number" 
                    placeholder="25000"
                    value={formData.km}
                    onChange={(e) => setFormData(prev => ({ ...prev, km: e.target.value }))}
                  />
                </div>
                <div className="col-span-2 space-y-2">
                  <Label htmlFor="chassis">Número do Chassis</Label>
                  <Input 
                    id="chassis" 
                    placeholder="Número do chassis"
                    value={formData.chassis}
                    onChange={(e) => setFormData(prev => ({ ...prev, chassis: e.target.value }))}
                  />
                </div>
                <div className="col-span-2 space-y-2">
                  <Label htmlFor="proprietario">Proprietário</Label>
                  <Select value={formData.proprietarioId} onValueChange={(value) => setFormData(prev => ({ ...prev, proprietarioId: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o proprietário" />
                    </SelectTrigger>
                    <SelectContent>
                      {clientes.map((cliente) => (
                        <SelectItem key={cliente.id} value={cliente.id}>
                          {cliente.nome}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setIsModalOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit">
                  Salvar Moto
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search and Filter */}
      <Card className="bg-white border-border rounded-xl shadow-sm">
        <CardContent className="p-4">
          <div className="flex items-center space-x-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Buscar por marca, modelo, placa ou proprietário..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button variant="outline">Filtros</Button>
          </div>
        </CardContent>
      </Card>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="bg-white border-border rounded-xl shadow-sm">
          <CardContent className="p-6">
            <div className="text-center">
              <p className="text-2xl font-semibold text-foreground">{motos.length}</p>
              <p className="text-sm text-muted-foreground">Total de Motos</p>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white border-border rounded-xl shadow-sm">
          <CardContent className="p-6">
            <div className="text-center">
              <p className="text-2xl font-semibold text-success">
                {motos.filter(m => m.status === 'Em Dia').length}
              </p>
              <p className="text-sm text-muted-foreground">Em Dia</p>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white border-border rounded-xl shadow-sm">
          <CardContent className="p-6">
            <div className="text-center">
              <p className="text-2xl font-semibold text-primary">
                {motos.filter(m => m.status === 'Revisão Próxima').length}
              </p>
              <p className="text-sm text-muted-foreground">Revisão Próxima</p>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white border-border rounded-xl shadow-sm">
          <CardContent className="p-6">
            <div className="text-center">
              <p className="text-2xl font-semibold text-secondary">
                {motos.filter(m => m.status === 'Revisão Atrasada').length}
              </p>
              <p className="text-sm text-muted-foreground">Revisão Atrasada</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Motos Grid */}
      {loading ? (
        <div className="text-center py-8">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-muted-foreground">Carregando motocicletas...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredMotos.length === 0 ? (
            <div className="col-span-full text-center py-8">
              <div className="w-12 h-12 mx-auto text-muted-foreground mb-4">🏍️</div>
              <p className="text-muted-foreground">Nenhuma motocicleta encontrada</p>
            </div>
          ) : (
            filteredMotos.map((moto) => (
              <Card key={moto.id} className="bg-white border-border rounded-xl shadow-sm">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg font-semibold text-foreground">
                      {moto.marca} {moto.modelo}
                    </CardTitle>
                    <Badge 
                      variant="default"
                      className={getStatusColor(moto.status)}
                    >
                      {moto.status}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Ano</p>
                      <p className="font-medium text-foreground">{moto.ano}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Cor</p>
                      <p className="font-medium text-foreground">{moto.cor}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Placa</p>
                      <p className="font-medium text-foreground">{moto.placa}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">KM</p>
                      <p className="font-medium text-foreground">{moto.km?.toLocaleString() || '0'}</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                      <User className="w-4 h-4" />
                      <span>{moto.proprietario}</span>
                    </div>
                    <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                      <Calendar className="w-4 h-4" />
                      <span>Próxima revisão: {moto.proximaRevisao}</span>
                    </div>
                    <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                      <MapPin className="w-4 h-4" />
                      <span>Chassis: {moto.chassis}</span>
                    </div>
                  </div>

                  <div className="flex space-x-2 pt-2">
                    <Button variant="outline" size="sm" className="flex-1">
                      <Edit className="w-4 h-4 mr-1" />
                      Editar
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="text-secondary border-secondary hover:bg-secondary/10"
                      onClick={() => handleDeleteMoto(moto.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      )}
    </div>
  );
}