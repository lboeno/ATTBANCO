import { projectId, publicAnonKey } from './supabase/info'

const API_BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-15b419ad`

// Helper to get auth token from localStorage
function getAuthToken(): string | null {
  return localStorage.getItem('supabase_auth_token')
}

// Helper to make authenticated requests
async function apiRequest(endpoint: string, options: RequestInit = {}) {
  const token = getAuthToken()
  
  const headers = {
    'Content-Type': 'application/json',
    'Authorization': token ? `Bearer ${token}` : `Bearer ${publicAnonKey}`,
    ...options.headers,
  }

  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    ...options,
    headers,
  })

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ error: 'Unknown error' }))
    throw new Error(errorData.error || `HTTP ${response.status}`)
  }

  return response.json()
}

// Auth API
export const authAPI = {
  async signup(email: string, password: string, name: string) {
    return apiRequest('/auth/signup', {
      method: 'POST',
      body: JSON.stringify({ email, password, name })
    })
  }
}

// Clientes API
export const clientesAPI = {
  async getAll() {
    return apiRequest('/clientes')
  },
  
  async create(cliente: any) {
    return apiRequest('/clientes', {
      method: 'POST',
      body: JSON.stringify(cliente)
    })
  },
  
  async update(id: string, cliente: any) {
    return apiRequest(`/clientes/${id}`, {
      method: 'PUT',
      body: JSON.stringify(cliente)
    })
  },
  
  async delete(id: string) {
    return apiRequest(`/clientes/${id}`, {
      method: 'DELETE'
    })
  }
}

// Motos API
export const motosAPI = {
  async getAll() {
    return apiRequest('/motos')
  },
  
  async create(moto: any) {
    return apiRequest('/motos', {
      method: 'POST',
      body: JSON.stringify(moto)
    })
  },
  
  async update(id: string, moto: any) {
    return apiRequest(`/motos/${id}`, {
      method: 'PUT',
      body: JSON.stringify(moto)
    })
  },
  
  async delete(id: string) {
    return apiRequest(`/motos/${id}`, {
      method: 'DELETE'
    })
  }
}

// Ordens API
export const ordensAPI = {
  async getAll() {
    return apiRequest('/ordens')
  },
  
  async create(ordem: any) {
    return apiRequest('/ordens', {
      method: 'POST',
      body: JSON.stringify(ordem)
    })
  }
}

// Dashboard API
export const dashboardAPI = {
  async getStats() {
    return apiRequest('/dashboard/stats')
  },
  
  async initSampleData() {
    return apiRequest('/init-sample-data', {
      method: 'POST'
    })
  }
}

// Health check
export const healthAPI = {
  async check() {
    return apiRequest('/health')
  }
}