import { Hono } from 'npm:hono@4.6.10'
import { cors } from 'npm:hono/cors'
import { logger } from 'npm:hono/logger'
import { createClient } from 'npm:@supabase/supabase-js@2'
import * as kv from './kv_store.tsx'

const app = new Hono()

// Middleware
app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}))

app.use('*', logger(console.log))

// Supabase client with service role key for admin operations
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
)

// Helper function to verify authentication
async function verifyAuth(request: Request) {
  const accessToken = request.headers.get('Authorization')?.split(' ')[1];
  if (!accessToken) {
    throw new Error('No authorization token provided');
  }
  
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  if (error || !user) {
    throw new Error('Invalid or expired token');
  }
  
  return user;
}

// Auth routes
app.post('/make-server-15b419ad/auth/signup', async (c) => {
  try {
    const body = await c.req.json()
    const { email, password, name } = body

    if (!email || !password || !name) {
      return c.json({ error: 'Email, password and name are required' }, 400)
    }

    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    })

    if (error) {
      console.log('Error creating user:', error)
      return c.json({ error: error.message }, 400)
    }

    // Store user profile in KV store
    await kv.set(`usuario:${data.user.id}`, {
      id: data.user.id,
      email,
      name,
      created_at: new Date().toISOString()
    })

    return c.json({ user: data.user })
  } catch (error) {
    console.log('Signup error:', error)
    return c.json({ error: 'Internal server error during signup' }, 500)
  }
})

// Cliente routes
app.get('/make-server-15b419ad/clientes', async (c) => {
  try {
    await verifyAuth(c.req.raw);
    
    const clientes = await kv.getByPrefix('cliente:');
    return c.json({ clientes: clientes.map(item => item.value) });
  } catch (error) {
    console.log('Error fetching clients:', error);
    return c.json({ error: 'Error fetching clients' }, 500);
  }
});

app.post('/make-server-15b419ad/clientes', async (c) => {
  try {
    await verifyAuth(c.req.raw);
    
    const body = await c.req.json();
    const { nome, email, telefone, cpf, endereco } = body;
    
    if (!nome || !email || !telefone) {
      return c.json({ error: 'Nome, email e telefone são obrigatórios' }, 400);
    }
    
    const id = crypto.randomUUID();
    const cliente = {
      id,
      nome,
      email,
      telefone,
      cpf: cpf || '',
      endereco: endereco || '',
      motosCount: 0,
      ultimaVisita: new Date().toISOString().split('T')[0],
      status: 'Ativo',
      created_at: new Date().toISOString()
    };
    
    await kv.set(`cliente:${id}`, cliente);
    return c.json({ cliente });
  } catch (error) {
    console.log('Error creating client:', error);
    return c.json({ error: 'Error creating client' }, 500);
  }
});

app.put('/make-server-15b419ad/clientes/:id', async (c) => {
  try {
    await verifyAuth(c.req.raw);
    
    const id = c.req.param('id');
    const body = await c.req.json();
    
    const existingClient = await kv.get(`cliente:${id}`);
    if (!existingClient) {
      return c.json({ error: 'Cliente não encontrado' }, 404);
    }
    
    const updatedClient = {
      ...existingClient,
      ...body,
      updated_at: new Date().toISOString()
    };
    
    await kv.set(`cliente:${id}`, updatedClient);
    return c.json({ cliente: updatedClient });
  } catch (error) {
    console.log('Error updating client:', error);
    return c.json({ error: 'Error updating client' }, 500);
  }
});

app.delete('/make-server-15b419ad/clientes/:id', async (c) => {
  try {
    await verifyAuth(c.req.raw);
    
    const id = c.req.param('id');
    await kv.del(`cliente:${id}`);
    return c.json({ message: 'Cliente excluído com sucesso' });
  } catch (error) {
    console.log('Error deleting client:', error);
    return c.json({ error: 'Error deleting client' }, 500);
  }
});

// Moto routes
app.get('/make-server-15b419ad/motos', async (c) => {
  try {
    await verifyAuth(c.req.raw);
    
    const motos = await kv.getByPrefix('moto:');
    return c.json({ motos: motos.map(item => item.value) });
  } catch (error) {
    console.log('Error fetching motorcycles:', error);
    return c.json({ error: 'Error fetching motorcycles' }, 500);
  }
});

app.post('/make-server-15b419ad/motos', async (c) => {
  try {
    await verifyAuth(c.req.raw);
    
    const body = await c.req.json();
    const { marca, modelo, ano, cor, placa, chassis, km, proprietarioId } = body;
    
    if (!marca || !modelo || !ano || !placa || !proprietarioId) {
      return c.json({ error: 'Marca, modelo, ano, placa e proprietário são obrigatórios' }, 400);
    }
    
    // Get proprietario name
    const proprietario = await kv.get(`cliente:${proprietarioId}`);
    if (!proprietario) {
      return c.json({ error: 'Proprietário não encontrado' }, 404);
    }
    
    const id = crypto.randomUUID();
    const proximaRevisao = new Date();
    proximaRevisao.setMonth(proximaRevisao.getMonth() + 6);
    
    const moto = {
      id,
      marca,
      modelo,
      ano: parseInt(ano),
      cor: cor || '',
      placa,
      chassis: chassis || '',
      km: parseInt(km) || 0,
      proprietarioId,
      proprietario: proprietario.nome,
      proximaRevisao: proximaRevisao.toISOString().split('T')[0],
      status: 'Em Dia',
      created_at: new Date().toISOString()
    };
    
    await kv.set(`moto:${id}`, moto);
    
    // Update cliente motosCount
    proprietario.motosCount = (proprietario.motosCount || 0) + 1;
    await kv.set(`cliente:${proprietarioId}`, proprietario);
    
    return c.json({ moto });
  } catch (error) {
    console.log('Error creating motorcycle:', error);
    return c.json({ error: 'Error creating motorcycle' }, 500);
  }
});

app.put('/make-server-15b419ad/motos/:id', async (c) => {
  try {
    await verifyAuth(c.req.raw);
    
    const id = c.req.param('id');
    const body = await c.req.json();
    
    const existingMoto = await kv.get(`moto:${id}`);
    if (!existingMoto) {
      return c.json({ error: 'Moto não encontrada' }, 404);
    }
    
    const updatedMoto = {
      ...existingMoto,
      ...body,
      updated_at: new Date().toISOString()
    };
    
    await kv.set(`moto:${id}`, updatedMoto);
    return c.json({ moto: updatedMoto });
  } catch (error) {
    console.log('Error updating motorcycle:', error);
    return c.json({ error: 'Error updating motorcycle' }, 500);
  }
});

app.delete('/make-server-15b419ad/motos/:id', async (c) => {
  try {
    await verifyAuth(c.req.raw);
    
    const id = c.req.param('id');
    const moto = await kv.get(`moto:${id}`);
    
    if (moto && moto.proprietarioId) {
      // Update cliente motosCount
      const proprietario = await kv.get(`cliente:${moto.proprietarioId}`);
      if (proprietario) {
        proprietario.motosCount = Math.max((proprietario.motosCount || 1) - 1, 0);
        await kv.set(`cliente:${moto.proprietarioId}`, proprietario);
      }
    }
    
    await kv.del(`moto:${id}`);
    return c.json({ message: 'Moto excluída com sucesso' });
  } catch (error) {
    console.log('Error deleting motorcycle:', error);
    return c.json({ error: 'Error deleting motorcycle' }, 500);
  }
});

// Ordem de Serviço routes
app.get('/make-server-15b419ad/ordens', async (c) => {
  try {
    await verifyAuth(c.req.raw);
    
    const ordens = await kv.getByPrefix('ordem:');
    return c.json({ ordens: ordens.map(item => item.value) });
  } catch (error) {
    console.log('Error fetching service orders:', error);
    return c.json({ error: 'Error fetching service orders' }, 500);
  }
});

app.post('/make-server-15b419ad/ordens', async (c) => {
  try {
    await verifyAuth(c.req.raw);
    
    const body = await c.req.json();
    const { clienteId, motoId, servico, descricao, valor, prazo } = body;
    
    if (!clienteId || !motoId || !servico || !valor) {
      return c.json({ error: 'Cliente, moto, serviço e valor são obrigatórios' }, 400);
    }
    
    const cliente = await kv.get(`cliente:${clienteId}`);
    const moto = await kv.get(`moto:${motoId}`);
    
    if (!cliente || !moto) {
      return c.json({ error: 'Cliente ou moto não encontrados' }, 404);
    }
    
    const id = crypto.randomUUID();
    const year = new Date().getFullYear();
    const orderNumber = `OS-${year}-${String(Date.now()).slice(-6)}`;
    
    const ordem = {
      id,
      numero: orderNumber,
      clienteId,
      cliente: cliente.nome,
      motoId,
      moto: `${moto.marca} ${moto.modelo}`,
      servico,
      descricao: descricao || '',
      valor: parseFloat(valor),
      prazo,
      status: 'Em Andamento',
      created_at: new Date().toISOString()
    };
    
    await kv.set(`ordem:${id}`, ordem);
    
    // Update cliente ultima visita
    cliente.ultimaVisita = new Date().toISOString().split('T')[0];
    await kv.set(`cliente:${clienteId}`, cliente);
    
    return c.json({ ordem });
  } catch (error) {
    console.log('Error creating service order:', error);
    return c.json({ error: 'Error creating service order' }, 500);
  }
});

// Dashboard stats
app.get('/make-server-15b419ad/dashboard/stats', async (c) => {
  try {
    await verifyAuth(c.req.raw);
    
    const [clientes, motos, ordens] = await Promise.all([
      kv.getByPrefix('cliente:'),
      kv.getByPrefix('moto:'),
      kv.getByPrefix('ordem:')
    ]);
    
    const clientesData = clientes.map(item => item.value);
    const motosData = motos.map(item => item.value);
    const ordensData = ordens.map(item => item.value);
    
    // Calculate monthly revenue
    const currentMonth = new Date().toISOString().slice(0, 7);
    const monthlyRevenue = ordensData
      .filter(ordem => ordem.created_at.startsWith(currentMonth))
      .reduce((sum, ordem) => sum + (ordem.valor || 0), 0);
    
    const stats = {
      totalClientes: clientesData.length,
      totalMotos: motosData.length,
      ordensAtivas: ordensData.filter(ordem => ordem.status === 'Em Andamento').length,
      faturamentoMensal: monthlyRevenue,
      clientesAtivos: clientesData.filter(cliente => cliente.status === 'Ativo').length
    };
    
    return c.json({ stats });
  } catch (error) {
    console.log('Error fetching dashboard stats:', error);
    return c.json({ error: 'Error fetching dashboard stats' }, 500);
  }
});

// Initialize sample data if none exists
app.post('/make-server-15b419ad/init-sample-data', async (c) => {
  try {
    await verifyAuth(c.req.raw);
    
    const existingClientes = await kv.getByPrefix('cliente:');
    if (existingClientes.length > 0) {
      return c.json({ message: 'Sample data already exists' });
    }
    
    // Create sample clients
    const sampleClientes = [
      {
        id: crypto.randomUUID(),
        nome: 'João Silva',
        email: 'joao@email.com',
        telefone: '(11) 99999-9999',
        cpf: '123.456.789-00',
        endereco: 'Rua das Flores, 123 - Centro',
        motosCount: 2,
        ultimaVisita: '2024-01-10',
        status: 'Ativo',
        created_at: new Date().toISOString()
      },
      {
        id: crypto.randomUUID(),
        nome: 'Maria Santos',
        email: 'maria@email.com',
        telefone: '(11) 88888-8888',
        cpf: '987.654.321-00',
        endereco: 'Av. Principal, 456 - Bairro',
        motosCount: 1,
        ultimaVisita: '2024-01-08',
        status: 'Ativo',
        created_at: new Date().toISOString()
      }
    ];
    
    for (const cliente of sampleClientes) {
      await kv.set(`cliente:${cliente.id}`, cliente);
    }
    
    return c.json({ message: 'Sample data created successfully' });
  } catch (error) {
    console.log('Error creating sample data:', error);
    return c.json({ error: 'Error creating sample data' }, 500);
  }
});

// Health check
app.get('/make-server-15b419ad/health', (c) => {
  return c.json({ status: 'healthy', timestamp: new Date().toISOString() });
});

Deno.serve(app.fetch);