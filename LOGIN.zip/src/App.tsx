import { useState, useEffect } from 'react';
import { Sidebar } from './components/sidebar';
import { Header } from './components/header';
import { Dashboard } from './components/dashboard';
import { Clientes } from './components/clientes';
import { Motos } from './components/motos';
import { Login } from './components/auth/login';
import { supabase } from './utils/supabase/client';

const sectionTitles: Record<string, string> = {
  dashboard: 'Dashboard',
  clientes: 'Clientes',
  motos: 'Motocicletas',
  ordens: 'Ordens de Serviço',
  estoque: 'Estoque',
  relatorios: 'Relatórios',
  configuracoes: 'Configurações'
};

export default function App() {
  const [activeSection, setActiveSection] = useState('dashboard');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authLoading, setAuthLoading] = useState(true);

  useEffect(() => {
    checkAuthStatus();
  }, []);

  const checkAuthStatus = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.access_token) {
        localStorage.setItem('supabase_auth_token', session.access_token);
        setIsAuthenticated(true);
      } else {
        const savedToken = localStorage.getItem('supabase_auth_token');
        if (savedToken) {
          const { data: { user } } = await supabase.auth.getUser(savedToken);
          setIsAuthenticated(!!user);
        }
      }
    } catch (error) {
      console.error('Auth check error:', error);
      setIsAuthenticated(false);
    } finally {
      setAuthLoading(false);
    }
  };

  const handleLogin = (token: string) => {
    localStorage.setItem('supabase_auth_token', token);
    setIsAuthenticated(true);
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    localStorage.removeItem('supabase_auth_token');
    localStorage.removeItem('user_email');
    setIsAuthenticated(false);
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-muted-foreground">Verificando autenticação...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Login onLogin={handleLogin} />;
  }

  const renderContent = () => {
    switch (activeSection) {
      case 'dashboard':
        return <Dashboard />;
      case 'clientes':
        return <Clientes />;
      case 'motos':
        return <Motos />;
      case 'ordens':
        return <div className="p-6"><h2>Ordens de Serviço - Em Desenvolvimento</h2></div>;
      case 'estoque':
        return <div className="p-6"><h2>Estoque - Em Desenvolvimento</h2></div>;
      case 'relatorios':
        return <div className="p-6"><h2>Relatórios - Em Desenvolvimento</h2></div>;
      case 'configuracoes':
        return <div className="p-6"><h2>Configurações - Em Desenvolvimento</h2></div>;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-background flex">
      <Sidebar 
        activeSection={activeSection} 
        onSectionChange={setActiveSection}
        onLogout={handleLogout}
      />
      <div className="flex-1 flex flex-col">
        <Header title={sectionTitles[activeSection]} />
        <main className="flex-1 overflow-auto">
          {renderContent()}
        </main>
      </div>
    </div>
  );
}