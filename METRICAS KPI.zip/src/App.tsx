import { useState } from 'react';
import { CustomerRegistration } from './components/CustomerRegistration';
import { FeedbackForm } from './components/FeedbackForm';
import { MetricsDashboard } from './components/MetricsDashboard';
import { Wrench, Users, MessageSquare, BarChart3 } from 'lucide-react';

type TabType = 'dashboard' | 'customers' | 'feedback';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="bg-blue-600 p-2 rounded-lg">
                <Wrench className="size-6 text-white" />
              </div>
              <div>
                <h1 className="text-slate-900">Sistema de Satisfação do Cliente</h1>
                <p className="text-sm text-slate-600">Oficina de Manutenção Mecânica</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
        <div className="bg-white rounded-lg shadow-sm p-1 flex gap-1">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-md transition-colors ${
              activeTab === 'dashboard'
                ? 'bg-blue-600 text-white'
                : 'text-slate-700 hover:bg-slate-100'
            }`}
          >
            <BarChart3 className="size-5" />
            <span>Dashboard de Métricas</span>
          </button>
          <button
            onClick={() => setActiveTab('customers')}
            className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-md transition-colors ${
              activeTab === 'customers'
                ? 'bg-blue-600 text-white'
                : 'text-slate-700 hover:bg-slate-100'
            }`}
          >
            <Users className="size-5" />
            <span>Cadastro de Clientes</span>
          </button>
          <button
            onClick={() => setActiveTab('feedback')}
            className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-md transition-colors ${
              activeTab === 'feedback'
                ? 'bg-blue-600 text-white'
                : 'text-slate-700 hover:bg-slate-100'
            }`}
          >
            <MessageSquare className="size-5" />
            <span>Coletar Feedback</span>
          </button>
        </div>
      </div>

      {/* Content Area */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'dashboard' && <MetricsDashboard />}
        {activeTab === 'customers' && <CustomerRegistration />}
        {activeTab === 'feedback' && <FeedbackForm />}
      </main>
    </div>
  );
}
