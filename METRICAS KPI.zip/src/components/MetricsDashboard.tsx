import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, Legend } from 'recharts';
import { TrendingUp, Users, MessageSquare, Award } from 'lucide-react';

// Mock data baseado nos dados de teste do PoC
const mockFeedbacks = [
  { id: 1, cliente: 'João Silva Santos', servico: 'Troca de Óleo', nota: 9, comentario: 'Serviço rápido e eficiente, equipe muito prestativa', data: '2025-11-15' },
  { id: 2, cliente: 'João Silva Santos', servico: 'Revisão Completa', nota: 8, comentario: 'Bom atendimento, mas demorou um pouco mais que o esperado', data: '2025-11-10' },
  { id: 3, cliente: 'Maria Oliveira Souza', servico: 'Troca de Pneus', nota: 10, comentario: 'Excelente serviço, profissionais muito capacitados', data: '2025-11-18' },
  { id: 4, cliente: 'Carlos Eduardo Lima', servico: 'Alinhamento e Balanceamento', nota: 7, comentario: 'Serviço OK, preço justo', data: '2025-11-12' },
  { id: 5, cliente: 'Ana Paula Costa', servico: 'Troca de Freios', nota: 9, comentario: 'Muito bom, recomendo!', data: '2025-11-20' },
  { id: 6, cliente: 'Roberto Ferreira', servico: 'Revisão Completa', nota: 6, comentario: 'Demorou muito', data: '2025-11-08' },
  { id: 7, cliente: 'Juliana Santos', servico: 'Troca de Óleo', nota: 10, comentario: 'Perfeito!', data: '2025-11-19' },
  { id: 8, cliente: 'Pedro Almeida', servico: 'Suspensão', nota: 8, comentario: 'Bom trabalho', data: '2025-11-14' },
];

export function MetricsDashboard() {
  // Cálculo do NPS
  const promotores = mockFeedbacks.filter(f => f.nota >= 9).length;
  const neutros = mockFeedbacks.filter(f => f.nota >= 7 && f.nota <= 8).length;
  const detratores = mockFeedbacks.filter(f => f.nota <= 6).length;
  const total = mockFeedbacks.length;
  const nps = Math.round(((promotores - detratores) / total) * 100);
  
  // Nota média geral
  const notaMedia = (mockFeedbacks.reduce((sum, f) => sum + f.nota, 0) / total).toFixed(2);

  // Nota média por serviço
  const serviceStats = mockFeedbacks.reduce((acc, f) => {
    if (!acc[f.servico]) {
      acc[f.servico] = { servico: f.servico, total: 0, soma: 0 };
    }
    acc[f.servico].total++;
    acc[f.servico].soma += f.nota;
    return acc;
  }, {} as Record<string, { servico: string; total: number; soma: number }>);

  const serviceData = Object.values(serviceStats).map(s => ({
    servico: s.servico,
    nota_media: parseFloat((s.soma / s.total).toFixed(2)),
    quantidade: s.total
  })).sort((a, b) => b.nota_media - a.nota_media);

  // Distribuição NPS para Pie Chart
  const npsDistribution = [
    { name: 'Promotores', value: promotores, color: '#22c55e' },
    { name: 'Neutros', value: neutros, color: '#eab308' },
    { name: 'Detratores', value: detratores, color: '#ef4444' }
  ];

  // Evolução temporal
  const evolutionData = mockFeedbacks.reduce((acc, f) => {
    if (!acc[f.data]) {
      acc[f.data] = { data: f.data, total: 0, soma: 0 };
    }
    acc[f.data].total++;
    acc[f.data].soma += f.nota;
    return acc;
  }, {} as Record<string, { data: string; total: number; soma: number }>);

  const evolutionChart = Object.values(evolutionData)
    .map(d => ({
      data: new Date(d.data).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }),
      nota_media: parseFloat((d.soma / d.total).toFixed(2)),
      feedbacks: d.total
    }))
    .sort((a, b) => a.data.localeCompare(b.data));

  const getNPSColor = (nps: number) => {
    if (nps >= 75) return 'text-green-600';
    if (nps >= 50) return 'text-yellow-600';
    if (nps >= 0) return 'text-orange-600';
    return 'text-red-600';
  };

  const getNPSLabel = (nps: number) => {
    if (nps >= 75) return 'Excelente';
    if (nps >= 50) return 'Muito Bom';
    if (nps >= 0) return 'Razoável';
    return 'Crítico';
  };

  return (
    <div className="space-y-6">
      {/* Header com título */}
      <div>
        <h2 className="text-slate-900">Dashboard de Métricas de Satisfação</h2>
        <p className="text-slate-600">Análise baseada em {total} avaliações de clientes</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardDescription className="flex items-center gap-2">
              <Award className="size-4" />
              Net Promoter Score
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className={`text-4xl ${getNPSColor(nps)}`}>{nps}</div>
            <p className="text-sm text-slate-600 mt-1">{getNPSLabel(nps)}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardDescription className="flex items-center gap-2">
              <TrendingUp className="size-4" />
              Nota Média Geral
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-4xl text-blue-600">{notaMedia}</div>
            <p className="text-sm text-slate-600 mt-1">De 10 pontos</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardDescription className="flex items-center gap-2">
              <MessageSquare className="size-4" />
              Total de Feedbacks
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-4xl text-purple-600">{total}</div>
            <p className="text-sm text-slate-600 mt-1">Avaliações coletadas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardDescription className="flex items-center gap-2">
              <Users className="size-4" />
              Taxa de Promotores
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-4xl text-green-600">{Math.round((promotores / total) * 100)}%</div>
            <p className="text-sm text-slate-600 mt-1">{promotores} clientes (nota 9-10)</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Distribuição NPS */}
        <Card>
          <CardHeader>
            <CardTitle>Distribuição NPS</CardTitle>
            <CardDescription>Classificação dos clientes por satisfação</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={npsDistribution}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {npsDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="mt-4 grid grid-cols-3 gap-2 text-sm">
              <div className="text-center">
                <div className="text-green-600">{promotores}</div>
                <div className="text-slate-600">Promotores</div>
              </div>
              <div className="text-center">
                <div className="text-yellow-600">{neutros}</div>
                <div className="text-slate-600">Neutros</div>
              </div>
              <div className="text-center">
                <div className="text-red-600">{detratores}</div>
                <div className="text-slate-600">Detratores</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Nota Média por Serviço */}
        <Card>
          <CardHeader>
            <CardTitle>Nota Média por Serviço</CardTitle>
            <CardDescription>Performance de cada tipo de serviço</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={serviceData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" domain={[0, 10]} />
                <YAxis dataKey="servico" type="category" width={120} tick={{ fontSize: 12 }} />
                <Tooltip />
                <Bar dataKey="nota_media" fill="#3b82f6" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Evolução Temporal */}
      <Card>
        <CardHeader>
          <CardTitle>Evolução Temporal das Notas</CardTitle>
          <CardDescription>Tendência de satisfação ao longo do tempo</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={evolutionChart}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="data" />
              <YAxis domain={[0, 10]} />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="nota_media" stroke="#3b82f6" strokeWidth={2} name="Nota Média" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Tabela de Feedbacks Recentes */}
      <Card>
        <CardHeader>
          <CardTitle>Feedbacks Recentes</CardTitle>
          <CardDescription>Últimas avaliações dos clientes</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-3 text-slate-700">Data</th>
                  <th className="text-left p-3 text-slate-700">Cliente</th>
                  <th className="text-left p-3 text-slate-700">Serviço</th>
                  <th className="text-center p-3 text-slate-700">Nota</th>
                  <th className="text-left p-3 text-slate-700">Comentário</th>
                </tr>
              </thead>
              <tbody>
                {mockFeedbacks.slice().reverse().map((feedback) => (
                  <tr key={feedback.id} className="border-b hover:bg-slate-50">
                    <td className="p-3 text-sm text-slate-600">
                      {new Date(feedback.data).toLocaleDateString('pt-BR')}
                    </td>
                    <td className="p-3 text-sm">{feedback.cliente}</td>
                    <td className="p-3 text-sm">{feedback.servico}</td>
                    <td className="p-3 text-center">
                      <span className={`inline-flex items-center justify-center w-10 h-10 rounded-full ${
                        feedback.nota >= 9 ? 'bg-green-100 text-green-700' :
                        feedback.nota >= 7 ? 'bg-yellow-100 text-yellow-700' :
                        'bg-red-100 text-red-700'
                      }`}>
                        {feedback.nota}
                      </span>
                    </td>
                    <td className="p-3 text-sm text-slate-600">{feedback.comentario}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
