import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { toast } from 'sonner@2.0.3';
import { User, FileText, Phone, Mail, Calendar } from 'lucide-react';

export function CustomerRegistration() {
  const [formData, setFormData] = useState({
    nome_completo: '',
    tipo_documento: 'CPF',
    valor_documento: '',
    data_nascimento: '',
    sexo: '',
    telefone: '',
    email: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Simulate UPSERT operation
    console.log('UPSERT Cliente:', formData);
    
    toast.success('Cliente cadastrado com sucesso!', {
      description: `${formData.nome_completo} foi adicionado ao sistema.`
    });
    
    // Reset form
    setFormData({
      nome_completo: '',
      tipo_documento: 'CPF',
      valor_documento: '',
      data_nascimento: '',
      sexo: '',
      telefone: '',
      email: ''
    });
  };

  const formatDocument = (value: string, type: string) => {
    const numbers = value.replace(/\D/g, '');
    
    if (type === 'CPF') {
      return numbers
        .slice(0, 11)
        .replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4')
        .replace(/(-\d{2})\d+?$/, '$1');
    } else {
      return numbers
        .slice(0, 14)
        .replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5')
        .replace(/(-\d{2})\d+?$/, '$1');
    }
  };

  const formatPhone = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    return numbers
      .slice(0, 11)
      .replace(/(\d{2})(\d{4,5})(\d{4})/, '($1) $2-$3')
      .replace(/(-\d{4})\d+?$/, '$1');
  };

  return (
    <Card className="max-w-3xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <User className="size-5" />
          Cadastro de Cliente
        </CardTitle>
        <CardDescription>
          Sistema com rotina UPSERT - atualiza se existir, cria se for novo
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Nome Completo */}
          <div className="space-y-2">
            <Label htmlFor="nome">Nome Completo *</Label>
            <Input
              id="nome"
              required
              value={formData.nome_completo}
              onChange={(e) => setFormData({ ...formData, nome_completo: e.target.value })}
              placeholder="João Silva Santos"
            />
          </div>

          {/* Documento */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="tipo_doc">Tipo de Documento *</Label>
              <Select
                value={formData.tipo_documento}
                onValueChange={(value) => setFormData({ ...formData, tipo_documento: value, valor_documento: '' })}
              >
                <SelectTrigger id="tipo_doc">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="CPF">CPF</SelectItem>
                  <SelectItem value="CNPJ">CNPJ</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="documento">
                <FileText className="size-4 inline mr-1" />
                Número do Documento *
              </Label>
              <Input
                id="documento"
                required
                value={formData.valor_documento}
                onChange={(e) => setFormData({ 
                  ...formData, 
                  valor_documento: formatDocument(e.target.value, formData.tipo_documento)
                })}
                placeholder={formData.tipo_documento === 'CPF' ? '123.456.789-00' : '12.345.678/0001-00'}
              />
            </div>
          </div>

          {/* Data de Nascimento e Sexo */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="data_nasc">
                <Calendar className="size-4 inline mr-1" />
                Data de Nascimento
              </Label>
              <Input
                id="data_nasc"
                type="date"
                value={formData.data_nascimento}
                onChange={(e) => setFormData({ ...formData, data_nascimento: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="sexo">Sexo</Label>
              <Select
                value={formData.sexo}
                onValueChange={(value) => setFormData({ ...formData, sexo: value })}
              >
                <SelectTrigger id="sexo">
                  <SelectValue placeholder="Selecione..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="M">Masculino</SelectItem>
                  <SelectItem value="F">Feminino</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Telefone e Email */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="telefone">
                <Phone className="size-4 inline mr-1" />
                Telefone
              </Label>
              <Input
                id="telefone"
                value={formData.telefone}
                onChange={(e) => setFormData({ ...formData, telefone: formatPhone(e.target.value) })}
                placeholder="(11) 99999-8888"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">
                <Mail className="size-4 inline mr-1" />
                E-mail
              </Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="joao.silva@email.com"
              />
            </div>
          </div>

          <Button type="submit" className="w-full">
            Cadastrar / Atualizar Cliente
          </Button>
        </form>

        <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <p className="text-sm text-blue-900">
            <strong>Rotina UPSERT:</strong> Se o documento já existir, os dados do cliente serão atualizados. 
            Caso contrário, um novo registro será criado.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
