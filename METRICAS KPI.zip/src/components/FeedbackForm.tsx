import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { toast } from 'sonner@2.0.3';
import { Star, MessageSquare } from 'lucide-react';

const SERVICES = [
  'Troca de Óleo',
  'Revisão Completa',
  'Troca de Pneus',
  'Alinhamento e Balanceamento',
  'Troca de Freios',
  'Suspensão',
  'Sistema Elétrico',
  'Ar Condicionado',
  'Outro'
];

export function FeedbackForm() {
  const [formData, setFormData] = useState({
    cpf_cliente: '',
    servico_realizado: '',
    nota: '',
    comentario: ''
  });
  const [hoverRating, setHoverRating] = useState(0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    console.log('Feedback:', formData);
    
    const nota = parseInt(formData.nota);
    let categoria = 'Neutro';
    if (nota >= 9) categoria = 'Promotor';
    else if (nota <= 6) categoria = 'Detrator';
    
    toast.success('Feedback registrado com sucesso!', {
      description: `Nota ${nota}/10 - Classificado como ${categoria}`
    });
    
    setFormData({
      cpf_cliente: '',
      servico_realizado: '',
      nota: '',
      comentario: ''
    });
  };

  const formatCPF = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    return numbers
      .slice(0, 11)
      .replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4')
      .replace(/(-\d{2})\d+?$/, '$1');
  };

  const renderStars = () => {
    const stars = [];
    for (let i = 1; i <= 10; i++) {
      const isFilled = i <= (hoverRating || parseInt(formData.nota) || 0);
      stars.push(
        <button
          key={i}
          type="button"
          onClick={() => setFormData({ ...formData, nota: i.toString() })}
          onMouseEnter={() => setHoverRating(i)}
          onMouseLeave={() => setHoverRating(0)}
          className="transition-all hover:scale-110"
        >
          <Star
            className={`size-8 ${
              isFilled
                ? 'fill-yellow-400 text-yellow-400'
                : 'text-slate-300'
            }`}
          />
        </button>
      );
    }
    return stars;
  };

  const getNotaColor = (nota: number) => {
    if (nota >= 9) return 'text-green-600';
    if (nota >= 7) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <Card className="max-w-3xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MessageSquare className="size-5" />
          Coletar Feedback do Cliente
        </CardTitle>
        <CardDescription>
          Sistema de avaliação de satisfação - Escala de 0 a 10
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* CPF do Cliente */}
          <div className="space-y-2">
            <Label htmlFor="cpf">CPF do Cliente *</Label>
            <Input
              id="cpf"
              required
              value={formData.cpf_cliente}
              onChange={(e) => setFormData({ ...formData, cpf_cliente: formatCPF(e.target.value) })}
              placeholder="123.456.789-00"
            />
          </div>

          {/* Serviço Realizado */}
          <div className="space-y-2">
            <Label htmlFor="servico">Serviço Realizado *</Label>
            <Select
              value={formData.servico_realizado}
              onValueChange={(value) => setFormData({ ...formData, servico_realizado: value })}
              required
            >
              <SelectTrigger id="servico">
                <SelectValue placeholder="Selecione o serviço..." />
              </SelectTrigger>
              <SelectContent>
                {SERVICES.map((service) => (
                  <SelectItem key={service} value={service}>
                    {service}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Nota com Estrelas */}
          <div className="space-y-3">
            <Label>Nota de Satisfação (0-10) *</Label>
            <div className="flex items-center gap-1">
              {renderStars()}
            </div>
            {formData.nota && (
              <div className="flex items-center gap-4 p-3 bg-slate-50 rounded-lg">
                <div className={`text-3xl ${getNotaColor(parseInt(formData.nota))}`}>
                  {formData.nota}/10
                </div>
                <div className="text-sm text-slate-600">
                  {parseInt(formData.nota) >= 9 && '🎉 Promotor - Cliente muito satisfeito!'}
                  {parseInt(formData.nota) >= 7 && parseInt(formData.nota) <= 8 && '😊 Neutro - Cliente satisfeito'}
                  {parseInt(formData.nota) <= 6 && '😕 Detrator - Precisa melhorar'}
                </div>
              </div>
            )}
          </div>

          {/* Comentário */}
          <div className="space-y-2">
            <Label htmlFor="comentario">Comentário</Label>
            <Textarea
              id="comentario"
              value={formData.comentario}
              onChange={(e) => setFormData({ ...formData, comentario: e.target.value })}
              placeholder="Descreva a experiência do cliente..."
              rows={4}
            />
          </div>

          <Button type="submit" className="w-full" disabled={!formData.nota}>
            Registrar Feedback
          </Button>
        </form>

        {/* NPS Info */}
        <div className="mt-6 grid grid-cols-3 gap-3">
          <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
            <div className="text-xs text-green-700">Promotores</div>
            <div className="text-green-900">Nota 9-10</div>
          </div>
          <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
            <div className="text-xs text-yellow-700">Neutros</div>
            <div className="text-yellow-900">Nota 7-8</div>
          </div>
          <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
            <div className="text-xs text-red-700">Detratores</div>
            <div className="text-red-900">Nota 0-6</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
